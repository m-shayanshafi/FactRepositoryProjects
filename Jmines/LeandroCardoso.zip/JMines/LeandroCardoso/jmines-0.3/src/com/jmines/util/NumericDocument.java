package com.jmines.util;
import javax.swing.text.*;

public class NumericDocument extends PlainDocument
{
	private boolean negative;
	private int digits;
		
	public NumericDocument()
	{
		super();
		init();
	}
		
	public NumericDocument( boolean n )
	{
		super();
		init();
		setCanBeNegative( n );
	}
	
	public NumericDocument( int d )
	{
		super();
		init();
		setDigits( d );
	}
	
	public NumericDocument( boolean n, int d )
	{
		super();
		init();
		setCanBeNegative( n );
		setDigits( d );
	}

	private void init()
	{
		setCanBeNegative( true );
		setDigits( 0 );
	}

	public void insertString( int offs, String str, AttributeSet a )
		throws BadLocationException
	{
		if ( str == null )
		{
			return;
		}
			
		char[] number = new char[ str.length() ];
		int numberPos = 0;
		int maxDigits = digits;
		
		if ( getText( 0, 1 ).charAt( 0) == '-' )
		{
			++maxDigits;
		}
		
		for ( int i = 0; i < str.length() && (numberPos + getLength()) < maxDigits; ++i )
		{
			switch ( str.charAt( i ) )
			{
				case '-':
					if ( negative && numberPos + offs == 0 && getText( 0, 1 ).charAt( 0 ) != '-' )
					{
						number[ numberPos++ ] = str.charAt( i );
					}
					break;
						
				case '0':
				case '1':
				case '2':
				case '3':
				case '4':
				case '5':
				case '6':
				case '7':
				case '8':
				case '9':
					number[ numberPos++ ] = str.charAt( i );
					break;
			}
			
			if ( digits > 0 )
			{
				maxDigits = digits;
				
				if ( getText( 0, 1 ).charAt( 0 ) == '-' )
				{
					++maxDigits;
				}
			}
			else
			{
				maxDigits = Integer.MAX_VALUE;
			}
		}
			
		super.insertString( offs, new String( number, 0, numberPos ) , a );
	}
	
	public void setCanBeNegative( boolean n )
	{
		negative = n;
	}
	
	public boolean canBeNegative()
	{
		return negative;
	}
	
	public int getDigits()
	{
		return digits;
	}
	
	public void setDigits( int d )
	{
		if ( d >= 0 )
		{
			digits = d;
		}
		else
		{
			digits = 0;
		}
	}
}
