package com.jmines.util;
import java.util.*;

public class Chronometer
{
	//mode
	private Vector time;
	
	public Chronometer()
	{
		time = new Vector( 2 );
	}
	
	public void reset()
	{
		time.clear();
	}
	
	public void start()
	{
		if ( !isRunning() )
		{
			time.add( new Long( System.currentTimeMillis() ) );
		}
	}
	
	public void stop()
	{
		if ( isRunning() )
		{
			time.add( new Long( System.currentTimeMillis() ) );
		}
	}
	
	public boolean isStarted()
	{
		return !time.isEmpty();
	}
	
	public boolean isRunning()
	{
		return ( time.size() % 2 ) == 1;
	}
	
	public boolean isStopped()
	{
		return ( time.size() % 2 ) == 0; 
	}
	
	public long getTime()
	{
		long timeCron = 0;
		
		for ( Enumeration enum = time.elements(); enum.hasMoreElements(); )
		{
			timeCron -= ( (Long)enum.nextElement() ).longValue();
			
			if ( enum.hasMoreElements() )
			{
				timeCron += ( (Long)enum.nextElement() ).longValue();
			}
			else
			{
				timeCron += System.currentTimeMillis();
			}
		}

		return timeCron;
	}
	
	public long getStartedTime() throws IllegalStateException
	{
		if ( isRunning() )
		{
			throw new IllegalStateException( "The chronometer is running." );
		}

		return ( (Long)time.firstElement() ).longValue();
	}
	
	public long getStoppedTime() throws IllegalStateException
	{
		if ( isRunning() )
		{
			throw new IllegalStateException( "The chronometer is running." );
		}

		return ( (Long)time.lastElement() ).longValue();
	}
	
	public long getInterruptedTime() throws IllegalStateException
	{
		try
		{
			return getStoppedTime() - getStartedTime();
		}
		catch( IllegalStateException e )
		{
			throw e;
		}
	}
}
