package com.jmines.gui;

import java.awt.*;
import java.awt.event.*;
import java.text.*;

import javax.swing.*;



import com.jgoodies.forms.builder.*;
import com.jgoodies.forms.factories.*;
import com.jgoodies.forms.layout.*;
import com.jmines.core.*;
import com.jmines.util.*;

public class CustomGUI extends JFrame
{
	private JMines jMines;
	private SystemImage systemImage;
	
	//GUI
	
	private ButtonHandler buttonHandler;
	private FieldHandler fieldHandler;
	
	private Container container;
	
	private NumericField heightField;
	private NumericField widthField;
	private NumericField minesField;
	private JLabel percentText;
	
	private JButton okButton;
	private JButton cancelButton;

	
	public CustomGUI( JMines jm )
	{
		super( "Custom Board" );
		
		jMines = jm;
		systemImage = SystemImage.getInstance();
		
		setIconImage( systemImage.getImage( SystemImage.ICON ) );
		setResizable( false );
		setSize( 320, 260 );
		setDefaultCloseOperation( JFrame.HIDE_ON_CLOSE );
		
		initGUI();
		
		Rectangle rect = getGraphicsConfiguration().getBounds();
		int screenWidth = rect.width;
		int screenHeight = rect.height;
		setLocation( ( screenWidth - getWidth() ) /2, ( screenHeight - getHeight() ) /2 );
	}
	
	private void initGUI()
	{
		buttonHandler = new ButtonHandler();
		fieldHandler = new FieldHandler();

		container = getContentPane();
		container.setLayout( new BorderLayout() );
		
		container.add( getTitlePanel(), BorderLayout.NORTH );
		container.add( getFormPanel(), BorderLayout.CENTER );
		container.add( getButtonPanel(), BorderLayout.SOUTH );
	}
	
	private JPanel getTitlePanel()
	{
		TitlePanel titlePanel = new TitlePanel( TitlePanel.LEFT );
		titlePanel.setImage( systemImage.getImageIcon( SystemImage.CUSTOM ) );
		titlePanel.addTitleWithGlue( "Configure Custom Board" );
		
		return titlePanel;
	}

	private JPanel getFormPanel()
	{
		FormLayout layout = new FormLayout(
			"right:pref, 4dlu, 30dlu, 4dlu, left:pref",
			"pref, 4dlu, pref, 4dlu, pref" );
		
		CellConstraints cc = new CellConstraints();
		PanelBuilder builder = new PanelBuilder( layout );
		
		builder.setDefaultDialogBorder();
		
		widthField = new NumericField( false, 2 );
		widthField.addKeyListener( fieldHandler );
		
		heightField = new NumericField( false, 2 );
		heightField.addKeyListener( fieldHandler );
		
		minesField = new NumericField( false, 3 );
		minesField.addKeyListener( fieldHandler );
		
		percentText = new JLabel();

		builder.addLabel( "Width",  cc.xy( 1, 1 ) );
		builder.add( widthField, 	 cc.xy( 3, 1 ) );
		builder.addLabel( "Height", cc.xy( 1, 3 ) );
		builder.add( heightField, 	 cc.xy( 3, 3 ) );
		builder.addLabel( "Mines",  cc.xy( 1, 5 ) );
		builder.add( minesField, 	 cc.xy( 3, 5 ) );
		builder.add( percentText,	 cc.xy( 5, 5 ) );
		
		return builder.getPanel();
	}
	
	private JPanel getButtonPanel()
	{
		okButton = new JButton( "OK" );
		okButton.addActionListener( buttonHandler );
		cancelButton = new JButton( "Cancel" );
		cancelButton.addActionListener( buttonHandler );

		JPanel panel = ButtonBarFactory.buildCenteredBar( okButton, cancelButton ); 
		panel.setBorder( Borders.DLU2_BORDER );

		return panel; 
	}

	//metodo sobrescrito
	public void show()
	{
		int x = jMines.getGame().getBoard().getSelectedTemplate().getWidth();
		int y = jMines.getGame().getBoard().getSelectedTemplate().getHeight();
		int mines = jMines.getGame().getBoard().getSelectedTemplate().getMinesCount();
		
		widthField.setNumber( x );
		heightField.setNumber( y );
		minesField.setNumber( mines );

		updatePercentText();
		
		super.show();
	}

	//metodo sobrescrito
	public void hide()
	{
		jMines.setEnabled( true );
		super.hide();
	}
	
	private void updatePercentText()
	{
		int x = (int)widthField.getNumber();
		int y = (int)heightField.getNumber();
		int mines = (int)minesField.getNumber();
		
		DecimalFormat decimalFormat = new DecimalFormat( "#0.00%" );
		percentText.setText( decimalFormat.format( (double)mines / ( x * y ) ) );
	}


	private class ButtonHandler implements ActionListener
	{
		public void actionPerformed( ActionEvent e )
		{
			if ( e.getSource() == okButton )
			{
				int w = (int)widthField.getNumber();
				int h = (int)heightField.getNumber();
				int m = (int)minesField.getNumber();
				
				jMines.getGame().getBoard().getTemplate( Game.CUSTOM ).set( m, w, h );
				jMines.newGame( Game.CUSTOM );
			}
			else
			if ( e.getSource() == cancelButton )
			{
				jMines.selectButtonGroup();
			}
			
			hide();
		}
	}
	
	private class FieldHandler implements KeyListener
	{

		public void keyPressed( KeyEvent e )
		{
		}

		public void keyReleased( KeyEvent e )
		{
			updatePercentText();
		}

		public void keyTyped( KeyEvent e )
		{
		}
	}
}