package com.jmines.core;

import java.awt.Point;
import java.io.*;

import javax.swing.JPanel;

import com.jmines.util.FixedGridLayout;


public class Board extends JPanel
{
	//localizacao relativas das celulas vizinhas
	private static final Point[] NEIBOR_CELLS = {
		new Point( -1, -1 ),
		new Point( -1,  0 ),
		new Point( -1,  1 ),
		new Point(  0,  1 ),
		new Point(  1,  1 ),
		new Point(  1,  0 ),
		new Point(  1, -1 ),
		new Point(  0, -1 )
	};

	private Template[] template;
	private int selectedTemplate;
	private Cell[][] cell;
	private boolean explosion;
	
	private FixedGridLayout layout;
	
	
	public Board()
	{
		layout = new FixedGridLayout();
		layout.setComponentSize( Cell.getSkin().getImageSize(), Cell.getSkin().getImageSize() );
		layout.setBorderSize( 5 );
		setLayout( layout );
	}
	
	private void resetAllCells()
	{
		int height = template[ selectedTemplate ].getHeight();
		int width  = template[ selectedTemplate ].getWidth();
		
		for ( int y = 0; y < height; ++y )
		{
			for ( int x = 0; x < width; ++x )
			{
				cell[x][y].reset();
			}
		}
		repaint();
	}
	
	public void showMinesAllCells()
	{
		int height = template[ selectedTemplate ].getHeight();
		int width  = template[ selectedTemplate ].getWidth();
		
		for ( int y = 0; y < height; ++y )
		{
			for ( int x = 0; x < width; ++x )
			{
				cell[x][y].showMine();
			}
		}
		repaint();
	}
	
	public void showFlagsAllCells()
	{
		int height = template[ selectedTemplate ].getHeight();
		int width  = template[ selectedTemplate ].getWidth();
		
		for ( int y = 0; y < height; ++y )
		{
			for ( int x = 0; x < width; ++x )
			{
				cell[x][y].showFlag();
			}
		}
		repaint();
	}

	public void reset()
	{
		Cell.resetCounts();
		resetAllCells();
		putMines();
		explosion = false;
	}
	
	private void putMines()
	{ 
		int height = template[ selectedTemplate ].getHeight();
		int width  = template[ selectedTemplate ].getWidth();
		int mines  =  template[ selectedTemplate ].getMinesCount();
		
		for ( int i = 0; i < mines; ++i )
		{
			int x;
			int y;
			do
			{
				x = (int) ( Math.random() * width );
				y = (int) ( Math.random() * height );
			}while ( cell[x][y].isMine() );
			
			cell[x][y].setMine( true );
		}
		
		setNeiborMines();
	}
	
	private void setNeiborMines()
	{
		int height = template[ selectedTemplate ].getHeight();
		int width  = template[ selectedTemplate ].getWidth();
		int neiborMines;
		
		for ( int y = 0; y < height; ++y )
		{
			for ( int x = 0; x < width; ++x )
			{
				if ( !cell[x][y].isMine() )
				{
					neiborMines = 0;
					Cell[] neiborCell = getNeiborCells( cell[x][y] );
					
					for ( int i = 0; i < neiborCell.length; ++i )
					{
						if ( neiborCell[i].isMine() )
						{
							++neiborMines;
						}
					}
					
					cell[x][y].setNeiborMines( neiborMines );
				}
			}
		}
	}

	public Cell[] getNeiborCells( Cell cellSource )
	{
		Point[] tmp = new Point[ NEIBOR_CELLS.length ];
		int pos = 0;
		
		for ( int i = 0; i < NEIBOR_CELLS.length; ++i )
		{
			if ( template[ selectedTemplate ].isValidCellAt( new Point( NEIBOR_CELLS[i].x + cellSource.getPosition().x, NEIBOR_CELLS[i].y + cellSource.getPosition().y ) ) )
			{
				tmp[ pos ] = new Point( NEIBOR_CELLS[i] );
				tmp[ pos ].translate( cellSource.getPosition().x, cellSource.getPosition().y );
				++pos;
			}
		}
		
		Cell[] neiborCell = new Cell[ pos ];
		
		for ( int i = 0; i < pos; ++i )
		{
			neiborCell[i] = cell[ tmp[i].x ][ tmp[i].y ];
		}
		
		return neiborCell;
	}
	
	public boolean uncoverCell( Cell cellSource )
	{
		if ( !cellSource.uncover() )
		{
			return false;
		}
		
		explosion = explosion || cellSource.isMine();
		
		if ( cellSource.isClear() )
		{
			uncoverNeiborCells( cellSource );
		}
		
		return true;
	}
	
	public void uncoverNeiborCells( Cell cellSource )
	{
		Cell[] neiborCell = getNeiborCells( cellSource );
			
		for ( int i = 0; i < neiborCell.length; ++i )
		{
			uncoverCell( neiborCell[i] );
		}
	}
	
	private Cell[] getClearCells()
	{
		int width = template[ selectedTemplate ].getWidth();
		int height = template[ selectedTemplate ].getHeight();
		Cell []tmp = new Cell[ width * height ];
		int pos = 0;
		
		for ( int y = 0; y < height; ++y )
		{
			for ( int x = 0; x < width; ++x )
			{
				if ( cell[x][y].isClear() )
				{
					tmp[ pos++ ] = cell[x][y];
				}
			}
		}
		
		Cell []cells = new Cell[ pos ];
		
		for ( int i = 0; i < pos; ++i )
		{
			cells[i] = tmp[i];
		}
		
		return cells;
	}
	
	public void uncoverOneClearArea()
	{
		Cell []clearCell = getClearCells();
		int pos = (int)(Math.random() * clearCell.length);
		uncoverCell( clearCell[ pos ] );
	}
	
	public void uncoverAllClearAreas()
	{
		Cell []clearCell = getClearCells();
		Cell []neiborCell;
		
		for ( int pos = 0; pos < clearCell.length; ++pos )
		{
			clearCell[ pos ].uncover();
			neiborCell = getNeiborCells( clearCell[ pos ] );
			
			for ( int i = 0; i < neiborCell.length; ++i )
			{
				neiborCell[i].uncover();
			}
		}
	}

	public boolean isGameLose()
	{
		return explosion;
	}
	
	public boolean isGameWin()
	{
		return Cell.getCoverCount() + Cell.getMineMarkCount() + Cell.getQuestionMarkCount() == template[ selectedTemplate ].getMinesCount();
	}
	
	public Template getTemplate( int index )
	{
		return template[ index ];
	}
	
	public void setTemplate( Template[] newTemplate )
	{
		template = newTemplate;
		loadRecordsFromFile();
	}
	
	public int getSelectedTemplateIndex()
	{
		return selectedTemplate;
	}
	
	public void selectTemplate( int index )
	{
		selectedTemplate = index;
		
		Template tmplt = template[ selectedTemplate ];
		
		removeAll();
		layout.setColumns( tmplt.getWidth() );
		layout.setRows( tmplt.getHeight() );
		
		cell = new Cell[ tmplt.getWidth() ][ tmplt.getHeight() ];
		
		for ( int y = 0; y < tmplt.getHeight(); ++y )
		{
			for ( int x = 0; x < tmplt.getWidth(); ++x )
			{
				cell[x][y] = new Cell( new Point( x, y ) );
				add( cell[x][y] );
			}
		}
	}
	
	public Template getSelectedTemplate()
	{
		return template[ selectedTemplate ];
	}

	public void loadRecordsFromFile()
	{
		try
		{
			File file = new File( "records.dat" );
			
			if ( file.exists() )
			{
			
				ObjectInputStream input = new ObjectInputStream( new BufferedInputStream( new FileInputStream( file ) ) );
			
				for ( int i = 1; i < template.length; ++i )
				{
					template[i] = (Template)input.readObject();
				}
				input.close();
			}
			else
			{
				file.createNewFile();
				saveRecordsToFile();
			}
		}
		catch ( FileNotFoundException e )
		{
			System.err.println( "Error: File records.dat not found" );
			e.printStackTrace();
		}
		catch ( IOException e )
		{
			System.err.println( "Error: Erro reading records.dat" );
			e.printStackTrace();
		}
		catch ( ClassNotFoundException e )
		{
			System.err.println( "Error: Invalid file records.dat" );
			e.printStackTrace();
		}
	}
	
	public void saveRecordsToFile()
	{
		try
		{
			ObjectOutputStream output = new ObjectOutputStream( new BufferedOutputStream( new FileOutputStream( "records.dat" ) ) );

			for ( int i = 1; i < template.length; ++i )
			{
				output.writeObject( template[i] );
			}
			output.flush();
			output.close();
		}
		catch ( FileNotFoundException e )
		{
			System.err.println( "Error: File records.dat not found" );
			e.printStackTrace();
		}
		catch ( IOException e )
		{
			System.err.println( "Error: Erro writing records.dat" );
			e.printStackTrace();
		}
		
	}
}
