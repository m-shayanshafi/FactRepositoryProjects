package com.jmines.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import com.jmines.core.*;
import com.jmines.util.*;



public class AboutGUI extends JFrame
{
	private JMines jMines;
	private SystemImage systemImage;
	
	//GUI
	
	private Container container;
	private TitlePanel titlePanel;
	private JPanel buttonPanel;
	private JTextArea textArea;
	private JButton buttonExit;
	
	private static final String TEXT =  
		"\nBy Leandro Cardoso, 2004\n\n" +
		"This software is distributed under the terms of the GNU General Public License (GPL). See license.txt\n\n" +
		"This software is a alpha version. It has been in constant evolution\n" +
		"visit www.sourceforge.net/jmines for the new version\n" +
		"Send comments, bugs, suggestions for maverick_br@sourceforge.net. Your email is welcome\n\n" +
		"This software includes software developed by the JGoodies Karsten Lentzsch. http://www.jgoodies.com";
	
	public AboutGUI( JMines jm )
	{
		super( "About JMines" );
		
		jMines = jm;
		systemImage = SystemImage.getInstance();
		
		setIconImage( systemImage.getImage( SystemImage.ICON ) );
		setResizable( false );
		setSize( 400, 320 );
		setDefaultCloseOperation( HIDE_ON_CLOSE );
				
		initGUI();

		Rectangle rect = getGraphicsConfiguration().getBounds();
		int screenWidth = rect.width;
		int screenHeight = rect.height;
		setLocation( ( screenWidth - getWidth() ) /2, ( screenHeight - getHeight() ) /2 );
	}
	
	private void initGUI()
	{
		container = getContentPane();
		container.setLayout( new BorderLayout() );

		container.add( getTitlePanel(), BorderLayout.NORTH );
		container.add( getTextArea(), BorderLayout.CENTER );
		container.add( getButtonPanel(), BorderLayout.SOUTH );
	}
	
	private JPanel getButtonPanel()
	{
		buttonPanel = new JPanel( new FlowLayout( FlowLayout.RIGHT ) );
		
		buttonPanel.add( getButtonExit() );
		
		return buttonPanel;
	}
	
	private JPanel getTitlePanel()
	{
		titlePanel = new TitlePanel( TitlePanel.LEFT );
		
		titlePanel.setImage( systemImage.getImageIcon( SystemImage.MINE ) );
		titlePanel.addGlue();
		titlePanel.addTitle( "JMines - The Java Minesweeper game" );
		titlePanel.addText( "version 0.3" );
		titlePanel.addGlue();
		
		return titlePanel;
	}
	
	private JTextArea getTextArea()
	{
		textArea = new JTextArea( TEXT );
		
		textArea.setEditable( false );
		textArea.setFocusable( false );
		textArea.setOpaque( false );
		textArea.setLineWrap( true );
		textArea.setWrapStyleWord( true );
		textArea.setFont( new Font( "SansSerif", Font.PLAIN, 10 ) );
		
		return textArea;
	}
	
	private JButton getButtonExit()
	{
		buttonExit = new JButton( "Ok" );
		buttonExit.addActionListener( new ActionListener()
			{
				public void actionPerformed(ActionEvent arg0)
				{
					hide();
				}
			}
		);
		return buttonExit;
	}
	
	//metodo sobrescrito
	public void hide()
	{
		jMines.setEnabled( true );
		super.hide();
	}
}
