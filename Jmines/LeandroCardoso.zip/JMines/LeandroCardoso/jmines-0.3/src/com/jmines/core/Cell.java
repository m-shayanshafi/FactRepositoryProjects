package com.jmines.core;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class Cell extends JComponent
{
	//status
	private static final int COVER = 0,
							 UNCOVER = 1,
							 MINE_MARK = 2,
							 QUESTION_MARK = 3;
	private int status;

	private boolean showUncover;
	private int neiborMines;
	private boolean mine;
	private Point position;

	private MouseHandler mouseHandler = new MouseHandler();
	private static MouseListener control;
	private static CellSkin skin;
	private static int coverCount;
	private static int uncoverCount;
	private static int mineMarkCount;
	private static int questionMarkCount;

	private int image;

	public Cell( Point point )
	{
		super();
		
		setPosition( point );
		addMouseListener( mouseHandler );
		addMouseListener( control );

		setDoubleBuffered( true );
		setSize( skin.getImageSize(), skin.getImageSize() );
	}
	
	public boolean uncover()
	{
		if ( status != COVER )
		{
			return false;
		}

		setStatus( UNCOVER );
		
		if ( mine )
		{
			setImage( CellSkin.EXPLOSION );
		}
		else
		{
			setImage( CellSkin.NEIBORHOOD_MINES[ neiborMines ] );
		}
		
		return true;
	}
	
	public boolean mineMark()
	{
		if ( status == UNCOVER )
		{
			return false;
		}
		
		setStatus( MINE_MARK );
		setImage( CellSkin.MINE_MARK );
		return true;
	}
	
	public boolean questionMark()
	{
		if ( status == UNCOVER )
		{
			return false;
		}
		
		setStatus( QUESTION_MARK );
		setImage( CellSkin.QUESTION_MARK );
		return true;
	}
	
	public boolean unmark()
	{
		if ( status == UNCOVER )
		{
			return false;
		}
		
		setStatus( COVER );
		setImage( CellSkin.COVER );
		return true;
	}
	
	public boolean isCover()
	{
		return status == COVER;
	}

	public boolean isUncover()
	{
		return status == UNCOVER;
	}
	
	public boolean isMineMark()
	{
		return status == MINE_MARK;
	}
	
	public boolean isQuestionMark()
	{
		return status == QUESTION_MARK;
	}
	
	public boolean isMark()
	{
		return status == MINE_MARK || status == QUESTION_MARK;
	}
	
	public static void resetCounts()
	{
		coverCount = 0;
		uncoverCount = 0;
		mineMarkCount = 0;
		questionMarkCount = 0;
	}
	
	public static int getCoverCount()
	{
		return coverCount;
	}
	
	public static int getUncoverCount()
	{
		return uncoverCount;
	}
	
	public static int getMineMarkCount()
	{
		return mineMarkCount;
	}
	
	public static int getQuestionMarkCount()
	{
		return questionMarkCount;
	}
	
	public void reset()
	{
		status = COVER;
		showUncover = false;
		neiborMines = 0;
		mine = false;
		++coverCount;
		setImage( CellSkin.COVER );
	}
	
	public void showMine()
	{
		showUncover = true;
		
		switch ( status )
		{
			case COVER:
			case QUESTION_MARK:
				if ( mine )
				{
					setImage( CellSkin.MINE );
				}
				break;
			
			case MINE_MARK:
				if ( mine )
				{
					setImage( CellSkin.MINE );
				}
				else
				{
					setImage( CellSkin.MARK_ERROR );
				}
				break;
		}
	}
	
	public void showFlag()
	{
		showUncover = true;
		
		if ( mine )
		{
			setImage( CellSkin.MINE_MARK );
		}
	}

	public boolean isMine()
	{
		return mine;
	}

	public void setMine( boolean isMine )
	{
		mine = isMine;
	}

	public int getNeiborMines()
	{
		return neiborMines;
	}
	
	public boolean isClear()
	{
		return neiborMines == 0 && !mine;
	}

	public void setNeiborMines( int count )
	{
		neiborMines = count;
	}

	public Point getPosition()
	{
		return position;
	}

	public void setPosition( Point point )
	{
		position = point;
	}

	public int getStatus()
	{
		return status;
	}

	public static CellSkin getSkin()
	{
		return skin;
	}

	public static void setSkin( CellSkin skin )
	{
		Cell.skin = skin;
	}
	
	public static MouseListener getControl()
	{
		return control;
	}

	public static void setControl( MouseListener ctrl )
	{
		control = ctrl;
	}

	private void setStatus( int sta )
	{
		switch ( status )
		{
			case COVER:
				--coverCount;
				break;
			
			case UNCOVER:
				--uncoverCount;
				break;
			
			case MINE_MARK:
				--mineMarkCount;
				break;
			
			case QUESTION_MARK:
				--questionMarkCount;
				break;
		}
		
		status = sta;
		
		switch ( status )
		{
			case COVER:
				++coverCount;
				break;
			
			case UNCOVER:
				++uncoverCount;
				break;
			
			case MINE_MARK:
				++mineMarkCount;
				break;
			
			case QUESTION_MARK:
				++questionMarkCount;
				break;
		}
	}
	
	private void setImage( int img )
	{
		image = img;
	}

		
	//metodo sobrescrito
	public void paint( Graphics g )
	{		
		g.drawImage( skin.getImage( image ), 0, 0, this );
	}
	
	
	private class MouseHandler implements MouseListener
	{

		public void mouseClicked( MouseEvent e )
		{
		}

		public void mouseEntered( MouseEvent e )
		{
			Cell cellSource = (Cell)e.getSource();
			
			if ( cellSource.status == COVER && !cellSource.showUncover )
			{
				cellSource.setImage( CellSkin.MOUSE_OVER );
				cellSource.repaint();
			}
		}

		public void mouseExited( MouseEvent e )
		{
			Cell cellSource = (Cell)e.getSource();
			
			if ( cellSource.status == COVER && !cellSource.showUncover )
			{
				cellSource.setImage( CellSkin.COVER );
				cellSource.repaint();
			}
		}

		public void mousePressed( MouseEvent e )
		{
			Cell cellSource = (Cell)e.getSource();
			
			if ( cellSource.status == COVER && !cellSource.showUncover )
			{
				cellSource.setImage( CellSkin.PRESSED );
				cellSource.repaint();
			}
		}

		public void mouseReleased( MouseEvent e )
		{
		}
	}
}
