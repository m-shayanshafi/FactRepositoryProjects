package com.jmines.core;
import java.awt.*;
import java.io.*;

import javax.swing.*;

//Singleton implemetation

public final class SystemImage
{
	private static final String folder = "images"; 
	private static final String ext = ".gif";
	private static final String[] url =
	{
		"icon",
		"mine",
		"custom",
		"records"
	};
	
	public static final int ICON = 0,
							MINE = 1,
							CUSTOM = 2,
							RECORDS = 3;
	
	private static ImageIcon[] image = new ImageIcon[ url.length ];
	
	//Instance
	private static SystemImage systemImage;


	//evita que se possa instanciar um objeto dessa classe
	private SystemImage()
	{
	}
	
	public static SystemImage getInstance()
	{
		if ( systemImage == null )
		{
			systemImage = new SystemImage();
		}
		
		return systemImage;
	}
	
	public ImageIcon getImageIcon( int i )
	{
		if ( image[i] == null )
		{
			image[i] = new ImageIcon( folder + File.separator + url[i] + ext );
		}
			
		return image[i];
	}
	
	public Image getImage( int i )
	{
		return getImageIcon( i ).getImage();
	}
}
