package com.jmines.core;

import java.awt.Point;
import java.io.Serializable;

public class Template implements Serializable
{
	public static final int MIN_WIDTH = 5,
							MAX_WIDTH = 40,
							MIN_HEIGHT = 5,
							MAX_HEIGHT = 40,
							MIN_PERCENT_MINES = 10,
							MAX_PERCENT_MINES = 50; 

	public static final int BEST_TIME_LENGHT = 10;
	
	private int width;
	private int height;
	private int minesCount;
	private BestTime[] bestTime = new BestTime[ BEST_TIME_LENGHT ];
	
	public Template()
	{
		this( 0, 0, 0 );
	}
	
	public Template( int m, int w, int h )
	{
		for ( int i = 0; i < bestTime.length; ++i )
		{
			bestTime[i] = new BestTime();
		}

		set( m, w, h );
	}
	
	public boolean isValidCellAt( Point p )
	{
		if ( p.x >= 0 && p.x < width &&
			  p.y >= 0 && p.y < height )
		{
			return true; 
		}
		
		return false;
	}

	public BestTime getBestTime( int i )
	{
		return bestTime[i];
	}

	public int getMinesCount()
	{
		return minesCount;
	}

	public int getWidth()
	{
		return width;
	}

	public int getHeight()
	{
		return height;
	}
	
	public int getBestTimePosition( int time )
	{
		int pos = BEST_TIME_LENGHT;
		
		
		while( pos > 0 && ( time < bestTime[ pos - 1 ].time || bestTime[ pos - 1 ].time == 0 ) )
		{
			--pos;
		}

		return pos + 1;		
	}

	public void setBestTime( int time, long date, String name )
	{
		int pos = BEST_TIME_LENGHT;
		
		while( pos > 0 && ( time < bestTime[ pos - 1 ].time || bestTime[ pos - 1 ].time == 0 ) )
		{
			if ( pos < BEST_TIME_LENGHT )
			{
				bestTime[ pos ].time = bestTime[ pos - 1 ].time;
				bestTime[ pos ].date = bestTime[ pos - 1 ].date;
				bestTime[ pos ].name = bestTime[ pos - 1 ].name;
			}
			
			--pos;
		}
		
		if ( pos < BEST_TIME_LENGHT )
		{
			bestTime[ pos ].time = time;
			bestTime[ pos ].date = date;
			bestTime[ pos ].name = name;
		}
	}
	
	public void resetBestTime()
	{
		for ( int i = 0; i < BEST_TIME_LENGHT; ++i )
		{
			bestTime[i].reset();
		}
	}

	public void set( int m, int w, int h )
	{
		if ( w < MIN_WIDTH )
			width = MIN_WIDTH;
		else
		if ( w > MAX_WIDTH )
			width = MAX_WIDTH;
		else
			width = w;
			
		if ( h < MIN_HEIGHT )
			height = MIN_HEIGHT;
		else
		if ( h > MAX_HEIGHT )
			height = MAX_HEIGHT;
		else
			height = h;
		
		int minMines = (int)( width * height * MIN_PERCENT_MINES / 100 );
		int maxMines = (int)( width * height * MAX_PERCENT_MINES / 100 );
		
		if ( m < minMines )
			minesCount = minMines;
		else
		if ( m > maxMines )
			minesCount = maxMines;
		else
			minesCount = m;
		 
		resetBestTime();
	}
	
	public class BestTime implements Serializable
	{
		public int time;
		public long date;
		public String name;
		
		public void reset()
		{
			time = 0;
			date = 0;
			name = "";
		}
	}
}
