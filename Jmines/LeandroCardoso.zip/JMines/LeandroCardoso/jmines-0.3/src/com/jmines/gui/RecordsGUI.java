package com.jmines.gui;

import java.awt.*;
import java.awt.event.*;
import java.text.DateFormat;
import java.util.Date;

import javax.swing.*;
import javax.swing.event.*;

import com.jgoodies.forms.builder.DefaultFormBuilder;
import com.jgoodies.forms.factories.*;
import com.jgoodies.forms.layout.*;

import com.jmines.core.*;
import com.jmines.util.TitlePanel;


public class RecordsGUI extends JFrame
{
	private JMines jMines;

	private SystemImage systemImage;

	//GUI
	private ButtonHandler buttonHandler;

	private Container container;

	private JList levelSelect;

	private JLabel[] levelTimeText,
					 levelDateText,
					 levelNameText;

	private JButton okButton;

	private JButton resetButton;

	private static final String[] LEVEL_NAME = {
		"begginer", "intermediate", "expert", "professional", "master" };

	public RecordsGUI( JMines jm )
	{
		super( "Records" );
		
		jMines = jm;
		systemImage = SystemImage.getInstance();
		setIconImage( systemImage.getImage( SystemImage.ICON ) );
		
		setResizable( false );
		setSize( 400, 320 );
		setDefaultCloseOperation( JFrame.HIDE_ON_CLOSE );
		
		initGUI();
		
		Rectangle rect = getGraphicsConfiguration().getBounds();
		int screenWidth = rect.width;
		int screenHeight = rect.height;
		setLocation( (screenWidth - getWidth()) / 2,
				(screenHeight - getHeight()) / 2 );
	}

	private void initGUI()
	{
		buttonHandler = new ButtonHandler();
		container = getContentPane();
		container.setLayout( new BorderLayout() );
		
		container.add( getTitlePanel(), BorderLayout.NORTH );
		container.add( getFormPanel(), BorderLayout.CENTER );
		container.add( getButtonPanel(), BorderLayout.SOUTH );
	}

	private JPanel getTitlePanel()
	{
		TitlePanel titlePanel = new TitlePanel( TitlePanel.LEFT );
		titlePanel.setImage( systemImage.getImageIcon( SystemImage.RECORDS ) );
		titlePanel.addTitleWithGlue( "Records" );
		
		return titlePanel;
	}

	private JPanel getFormPanel()
	{
		levelTimeText = new JLabel[ Template.BEST_TIME_LENGHT ];
		levelDateText = new JLabel[ Template.BEST_TIME_LENGHT ];
		levelNameText = new JLabel[ Template.BEST_TIME_LENGHT ];
		
		levelSelect = new JList( LEVEL_NAME );
		levelSelect.addListSelectionListener( new ListHandler() );
		
		FormLayout layout = new FormLayout(
				"right:pref, 4dlu, right:20dlu, 4dlu, left:30dlu:grow, 4dlu, center:pref, 4dlu, center:45dlu",
				"" );
		
		CellConstraints cc = new CellConstraints();
		
		DefaultFormBuilder builder = new DefaultFormBuilder( layout );
		builder.setDefaultDialogBorder();
		builder.setLineGapSize( Sizes.dluY( 0 ) );
		
		for ( int i = 0; i < levelTimeText.length; ++i )
		{
			levelTimeText[ i ] = new JLabel();
			levelDateText[ i ] = new JLabel();
			levelNameText[ i ] = new JLabel();
		
			builder.append( (i + 1) + "." );
			builder.append( levelTimeText[ i ] );
			builder.append( levelNameText[ i ] );
			builder.append( levelDateText[ i ] );
			builder.nextLine();
		}
		
		builder.add( levelSelect, cc.xywh( 9, 1, 1, levelTimeText.length * 2 - 1, "fill, fill" ) );
		
		return builder.getPanel();
	}

	private JPanel getButtonPanel()
	{
		okButton = new JButton( "Ok" );
		okButton.addActionListener( buttonHandler );
		
		resetButton = new JButton( "Reset" );
		resetButton.addActionListener( buttonHandler );
		
		JPanel panel = ButtonBarFactory.buildCenteredBar( okButton, resetButton );
		panel.setBorder( Borders.DLU2_BORDER );
		
		return panel;
	}

	public void show()
	{
		levelSelect.setSelectedIndex( jMines.getGame().getBoard().getSelectedTemplateIndex() - 1 );
		updateTimes();
		
		super.show();
	}

	public void hide()
	{
		jMines.setEnabled( true );
		super.hide();
	}

	private void updateTimes()
	{
		int time;
		long date;
		String name;
		DateFormat dateFormat = DateFormat.getDateTimeInstance( DateFormat.SHORT, DateFormat.SHORT );

		for ( int i = 0; i < levelTimeText.length; ++i )
		{
			time = jMines.getGame().getBoard().getTemplate( Game.LEVEL[ levelSelect.getSelectedIndex() ] ).getBestTime( i ).time;			
			levelTimeText[ i ].setText( time / 10 + "." + time % 10 + "s" );
			
			if ( time > 0 )
			{
				date = jMines.getGame().getBoard().getTemplate( Game.LEVEL[ levelSelect.getSelectedIndex() ] ).getBestTime( i ).date;
				levelDateText[ i ].setText( dateFormat.format( new Date( date ) ) );
				
				name = jMines.getGame().getBoard().getTemplate( Game.LEVEL[ levelSelect.getSelectedIndex() ] ).getBestTime( i ).name;
			}
			else
			{
				name = "*nobody*";
				levelDateText[ i ].setText( "" );
			}
			
			levelNameText[ i ].setText( name );
		}
	}

	private void resetTimes()
	{
		int res = JOptionPane.showConfirmDialog( this,
				"Reset the records?\n All records will be lost",
				"Reset Records Confirmation", JOptionPane.YES_NO_OPTION );
		
		if ( res == JOptionPane.YES_OPTION )
		{
			for ( int i = 0; i < LEVEL_NAME.length; ++i )
			{
				jMines.getGame().getBoard().getTemplate( Game.LEVEL[ i ] ).resetBestTime();
			}
			
			jMines.getGame().getBoard().saveRecordsToFile();
			updateTimes();
		}
	}

	private class ButtonHandler implements ActionListener
	{
		public void actionPerformed( ActionEvent e )
		{
			if ( e.getSource() == okButton )
			{
				hide();
			}
			else
			if ( e.getSource() == resetButton )
			{
				resetTimes();
			}
		}
	}

	private class ListHandler implements ListSelectionListener
	{
		public void valueChanged( ListSelectionEvent e )
		{
			updateTimes();
		}
	}
}