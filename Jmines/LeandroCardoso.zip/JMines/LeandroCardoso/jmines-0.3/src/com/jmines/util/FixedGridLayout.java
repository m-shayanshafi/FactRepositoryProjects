package com.jmines.util;
import java.awt.*;

public class FixedGridLayout implements LayoutManager
{
	private int columns;
	private int rows;
	private int componentSizeX;
	private int componentSizeY;
	private int Hgap;
	private int Vgap;
	private int borderSize;
	
	
	public FixedGridLayout( int c, int r, int csx, int csy )
	{
		init( c, r, csx, csy );
	}
	
	public FixedGridLayout( int c, int r )
	{
		init( c, r , 0, 0 );
	}
	
	public FixedGridLayout()
	{
		init( 0, 0, 0, 0 );
	}
	
	private void init( int c, int r, int csx, int csy )
	{
		setColumns( c );
		setRows( r );
		setComponentSize( csx, csy );
		
		Hgap = 0;
		Vgap = 0;
		borderSize = 0;
	}

	public void removeLayoutComponent( Component c )
	{
	}

	public void layoutContainer( Container c )
	{
		int centerHgap = ( c.getWidth()  - minimumLayoutSize( c ).width  ) / 2;
		int centerVgap = ( c.getHeight() - minimumLayoutSize( c ).height ) / 2;
		
		int nextX = borderSize + centerHgap;
		int nextY = borderSize + centerVgap;
		
		int endColumn = columns * ( componentSizeX + Hgap ) + borderSize + centerHgap; 
		int endRow    =    rows * ( componentSizeY + Vgap ) + borderSize + centerVgap;
		
		Component[] comp = c.getComponents();
		
		for ( int i = 0; i < comp.length; ++i )
		{
			comp[i].setBounds( nextX, nextY, componentSizeX, componentSizeY );
			
			nextX += componentSizeX + Hgap;
			
			if ( nextX >= endColumn )
			{
				nextX = borderSize + centerHgap;
				nextY += componentSizeY + Vgap;
				
				if ( nextY >= endRow && i < comp.length - 1 )
				{
					endRow += componentSizeY + Vgap;
					++rows;
				}
			}
		}
	}

	public void addLayoutComponent( String s, Component c )
	{
	}

	public Dimension minimumLayoutSize( Container c )
	{
		int sizeX = columns * ( componentSizeX + Hgap ) + borderSize * 2;
		int sizeY =    rows * ( componentSizeY + Vgap ) + borderSize * 2;
		return new Dimension( sizeX, sizeY );
	}

	public Dimension preferredLayoutSize( Container c )
	{
		return minimumLayoutSize( c );
	}


	public int getColumns()
	{
		return columns;
	}

	public int getComponentSizeX()
	{
		return componentSizeX;
	}

	public int getComponentSizeY()
	{
		return componentSizeY;
	}

	public int getHgap()
	{
		return Hgap;
	}

	public int getRows()
	{
		return rows;
	}

	public int getVgap()
	{
		return Vgap;
	}

	public int getBorderSize()
	{
		return borderSize;
	}

	public void setColumns(int i)
	{
		if ( i > 0 )
		{
			columns = i;
		}
		else
			columns = 1;
	}

	public void setComponentSizeX(int i)
	{
		if ( i > 0 )
		{
			componentSizeX = i;
		}
		else
			componentSizeX = 1;
	}

	public void setComponentSizeY(int i)
	{
		if ( i > 0 )
		{
			componentSizeY = i;
		}
		else
			componentSizeY = 1;
	}
	
	public void setComponentSize( int x, int y )
	{
		setComponentSizeX( x );
		setComponentSizeY( y );
	}

	public void setHgap(int i)
	{
		Hgap = i;
	}

	public void setRows(int i)
	{
		if ( i > 0 )
		{
			rows = i;
		}
		else
			rows = 0;
	}

	public void setVgap(int i)
	{
		Vgap = i;
	}

	public void setBorderSize(int i)
	{
		if ( i >= 0)
		{
			borderSize = i;
		}
		else
			borderSize = 0;
	}

}