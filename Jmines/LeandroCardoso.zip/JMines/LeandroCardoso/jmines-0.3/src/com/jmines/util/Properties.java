package com.jmines.util;

import java.io.*;
import java.io.FileInputStream;


//Singleton implemetation
public class Properties extends java.util.Properties
{
	//Instance
	private static Properties properties;

	private String filename;
	private String header;

	//evita que se possa instanciar um objeto dessa classe
	private Properties()
	{
	}

	public static Properties getInstance()
	{
		if ( properties == null )
		{
			properties = new Properties();
		}
		return properties;
	}

	public String getFilename()
	{
		return filename;
	}

	public void setFilename( String newFilename )
	{
		filename = newFilename;
	}

	public String getHeader()
	{
		return header;
	}

	public void setHeader( String newHeader )
	{
		header = newHeader;
	}

	public void load()
	{
		try
		{
			BufferedInputStream inputStream = new BufferedInputStream( new FileInputStream( filename ) );
			load( inputStream );
		}
		catch ( FileNotFoundException e )
		{
			System.err.println( "Error: File " + filename + " not found" );
			e.printStackTrace();
		}
		catch ( IOException e )
		{
			e.printStackTrace();
		}
	}
	
	public void store()
	{
		try
		{
			BufferedOutputStream outputStream = new BufferedOutputStream( new FileOutputStream( filename ) );			
			store( outputStream, header );

		}
		catch ( FileNotFoundException e )
		{
			System.err.println( "Error: File " + filename + " not found" );
			e.printStackTrace();
		}
		catch ( IOException e )
		{
			e.printStackTrace();
		}
	}
}