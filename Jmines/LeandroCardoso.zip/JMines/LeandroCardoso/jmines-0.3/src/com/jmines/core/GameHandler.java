package com.jmines.core;

import java.awt.event.*;

import com.jmines.util.Properties;


public class GameHandler implements MouseListener
{
	private JMines jMines;
	
	//action
	public static final int NONE = 0,
							UNCOVER_CELL = 1,
							MARK_CELL = 2,
							UNCOVER_NEIBOR_CELLS = 3;
	
	//button
	public static final int BUTTON1 = 0,
							BUTTON2 = 1,
							BUTTON3 = 2;
	
	//action index
	public static final int CLOSED_ACTION = 0,
							OPENED_ACTION = 1;
	
	//button X action index
	private int[][] buttonAction = new int[3][2];
	
	public GameHandler( JMines jm )
	{
		jMines = jm;
		loadButtonAction();
	}
	
	public void loadButtonAction()
	{
		Properties properties = Properties.getInstance();
		
		buttonAction[ BUTTON1 ][ CLOSED_ACTION ] = Integer.parseInt( properties.getProperty( "buttonAction" + BUTTON1 + CLOSED_ACTION ) );
		buttonAction[ BUTTON1 ][ OPENED_ACTION ] = Integer.parseInt( properties.getProperty( "buttonAction" + BUTTON1 + OPENED_ACTION ) );
		buttonAction[ BUTTON2 ][ CLOSED_ACTION ] = Integer.parseInt( properties.getProperty( "buttonAction" + BUTTON2 + CLOSED_ACTION ) );
		buttonAction[ BUTTON2 ][ OPENED_ACTION ] = Integer.parseInt( properties.getProperty( "buttonAction" + BUTTON2 + OPENED_ACTION ) );
		buttonAction[ BUTTON3 ][ CLOSED_ACTION ] = Integer.parseInt( properties.getProperty( "buttonAction" + BUTTON3 + CLOSED_ACTION ) );
		buttonAction[ BUTTON3 ][ OPENED_ACTION ] = Integer.parseInt( properties.getProperty( "buttonAction" + BUTTON3 + OPENED_ACTION ) );
	}
	
	private void uncoverCell( Cell cellSource )
	{
		jMines.getGame().getBoard().uncoverCell( cellSource );
		jMines.getGame().getBoard().repaint();
		jMines.getGame().checkGame();
		jMines.checkStatus();
	}
	
	private void uncoverNeiborCells( Cell cellSource )
	{
		jMines.getGame().getBoard().uncoverNeiborCells( cellSource );
		jMines.getGame().checkGame();
		jMines.getGame().getBoard().repaint();
		jMines.checkStatus();
	}
	
	private void markCell( Cell cellSource )
	{
		if ( cellSource.isCover() ) 
		{
			cellSource.mineMark();
		}
		else
		if ( cellSource.isMineMark() && Properties.getInstance().getProperty( "questionMark" ).equals( "1" ) )
		{
			cellSource.questionMark();
		}
		else
		{	
			cellSource.unmark();
		}
	
		jMines.getGame().getBoard().repaint();
		jMines.getStatusBar().update();
	}
	
	public void mouseClicked( MouseEvent e )
	{
		if ( jMines.getGame().getStatus() == Game.RUNNING )
		{
			jMines.getGame().startGame();
			
			Cell cellSource = (Cell)e.getSource();
			int button = BUTTON1;
			int cellStatus = cellSource.isUncover() ? OPENED_ACTION : CLOSED_ACTION; 
			 
			switch ( e.getButton() )
			{
				case MouseEvent.BUTTON1:
					button = BUTTON1;
					break;
					
				case MouseEvent.BUTTON2:
					button = BUTTON2;
					break;
			
				case MouseEvent.BUTTON3:
					button = BUTTON3;
					break;
			}
			
			switch ( buttonAction[ button ][ cellStatus ] )
			{
				case UNCOVER_CELL:
					uncoverCell( cellSource );
					break;
				
				case MARK_CELL:
					markCell( cellSource );
					break;

				case UNCOVER_NEIBOR_CELLS:
					uncoverNeiborCells( cellSource );
					break;
			}
		}
	}

	public void mouseEntered( MouseEvent e )
	{
	}

	public void mouseExited( MouseEvent e )
	{
	}

	public void mousePressed( MouseEvent e )
	{
	}

	public void mouseReleased( MouseEvent e )
	{
	}
}