package com.jmines.gui;

import javax.swing.*;

import com.jmines.core.*;


public abstract class OptionsPanelGUI
{
	protected JMines jMines;
	protected String name = "";
	protected JPanel panel= new JPanel();
	
	public OptionsPanelGUI( JMines jm )
	{
		jMines = jm;
	}
	
	public JPanel getPanel()
	{
		return panel;
	}
	
	public String getName()
	{
		return name;
	}
	
	public abstract void loadConfiguration();
	public abstract void saveConfiguration();
}
