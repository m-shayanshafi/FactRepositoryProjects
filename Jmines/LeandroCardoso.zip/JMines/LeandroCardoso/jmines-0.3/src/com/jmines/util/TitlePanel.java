package com.jmines.util;
import java.awt.*;

import javax.swing.*;
import javax.swing.border.*;

public class TitlePanel extends JPanel
{
	public static final String LEFT = BorderLayout.WEST,
										RIGHT = BorderLayout.EAST;
	
	private boolean hasGlue;

	//GUI

	private JPanel imagePanel;
	private JLabel image;
	private Box textPanel;
	

	public TitlePanel( String imagePosition )
	{
		super();
		
		hasGlue = false;

		imagePanel = new JPanel( new FlowLayout() );
		imagePanel.setOpaque( false );
		//imagePanel.setBorder( new EmptyBorder( new Insets( 0, 0, 0, 0 ) ) );
		image = new JLabel();
		imagePanel.add( image );
		
		textPanel = Box.createVerticalBox();

		setLayout( new BorderLayout() );
		
		add( imagePanel, imagePosition );
		add( textPanel, BorderLayout.CENTER );	
		
		setBackground( new Color( 230, 230, 230 ) );
		setBorder( new EtchedBorder( EtchedBorder.LOWERED ) );
	}
	
	public JLabel setImage( Icon icon )
	{
		image.setIcon( icon );
		imagePanel.add( image );
		
		return image;
	}
	
	public JLabel addText( String text )
	{
		JLabel label = new JLabel( text );
		textPanel.add( label );
		hasGlue = false;
		return label;
	}
	
	public JLabel addTextWithGlue( String text )
	{
		JLabel label;
		
		addGlue();
		label = addText( text );
		addGlue();
		
		return label;
	}
	
	public JLabel addTitle( String text )
	{
		JLabel label = addText( text );
		label.setFont( label.getFont().deriveFont( Font.BOLD ) );
		
		return label;
	}
	
	public JLabel addTitleWithGlue( String text )
	{
		JLabel label = addTextWithGlue( text );
		label.setFont( label.getFont().deriveFont( Font.BOLD ) );
		
		return label;
	}
	
	public void addGlue()
	{
		if ( !hasGlue )
		{
			textPanel.add( Box.createVerticalGlue() );
			hasGlue = true;
		}
	}
}
