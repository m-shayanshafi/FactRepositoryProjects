package com.jmines.util;
import javax.swing.*;
import javax.swing.text.*;


public class NumericField extends JTextField
{
	public NumericField()
	{
		super( new NumericDocument(), null, 0 );
	}
	
	public NumericField( boolean negative )
	{
		super( new NumericDocument( negative ), null, 0 );
	}
	
	public NumericField( int digits )
	{
		super( new NumericDocument( digits ), null, 0 );
	}
	
	public NumericField( boolean negative, int digits )
	{
		super( new NumericDocument( negative, digits ), null, 0 );
	}
	
	protected Document createDefaultModel()
	{
		return new NumericDocument();
	}
	
	public void setDocument( Document document )
	{
		if ( document instanceof NumericDocument )
		{
			super.setDocument( document );
		}
	}
	
	public void setDocument( NumericDocument document )
	{
		super.setDocument( document );
	}
	
	public NumericDocument getNumericDocument()
	{
		return (NumericDocument)getDocument();
	}
	
	
	public long getNumber()
	{
		String number = getText();
		
		if ( number.length() > 0 )
		{
			return Long.parseLong( number );
		}
		else
		{
			return 0;
		}
	}
	
	public void setNumber( long number )
	{
		setText( Long.toString( number ) );
	}
	
	public boolean isNegative()
	{
		return getNumber() < 0;
	}
	
	public boolean isPositive()
	{
		return getNumber() >= 0;
	}
}
