package com.jmines.core;

import javax.swing.JOptionPane;

import com.jmines.util.*;


public class Game
{
	//status do jogo
	public static final int RUNNING = 0,
							WIN = 1,
							LOSE = 2;
	private int status;

	//templates dos niveis de dificudade
	public static final int CUSTOM = 0,
							LEVEL[] = { 1, 2, 3, 4, 5 };
	
	private Board board;
	private Chronometer chronometer;
	

	public Game()
	{
		Board board = new Board();
		
		Template[] template = new Template[6];
		template[0] = new Template();
		template[1] = new Template( 10,  8,  8 );
		template[2] = new Template( 40, 16, 16 );
		template[3] = new Template( 99, 30, 16 );
		template[4] = new Template( 120, 24, 24 );
		template[5] = new Template( 256, 32, 32 );
		
		board.setTemplate( template );
		
 		init( board );
	}
	
	public Game( Board board )
	{
		init( board );
	}
	
	//funcao chamada apenas e por todos os construtores
	private void init( Board board )
	{
		status = -1;
		chronometer = new Chronometer();
		setBoard( board );
	}
	
	public void newGame()
	{
		if ( status == RUNNING )
		{
			stopGame();
		}
		
		chronometer.reset();
		board.reset();

		String clearStart = Properties.getInstance().getProperty( "clearStart" );
		if ( clearStart.equals( "1" ) ) //clear one area
		{
			board.uncoverOneClearArea();
		}
		else
		if ( clearStart.equals( "2" ) ) //clear all areas
		{
			board.uncoverAllClearAreas();
		}
		
		status = RUNNING; 
	}
	
	public void newGame( int newLevel )
	{
		board.selectTemplate( newLevel );
		newGame();
	}
	
	public void startGame()
	{
		if ( !chronometer.isStarted() )
		{
			chronometer.start();
		}
	}
	
	public void winGame()
	{
		status = WIN;
		stopGame();

		Template template = board.getSelectedTemplate();
		
		int time = (int)chronometer.getTime() / 100;
		int pos = template.getBestTimePosition( time );
				
		if ( pos <= Template.BEST_TIME_LENGHT )
		{
			String nome = JOptionPane.showInputDialog(
				null,
				"Congratulations! You have a " + pos + " fastest time.\nEnter your name", "New Record",
				JOptionPane.INFORMATION_MESSAGE );
			template.setBestTime( time, chronometer.getStoppedTime(), nome );
			board.saveRecordsToFile();
		}
		
		board.showFlagsAllCells();
	}
	
	public void loseGame()
	{
		status = LOSE;
		stopGame();
		board.showMinesAllCells();
	}
	
	public void stopGame()
	{
		stopChronometer();
		
		if ( status == RUNNING )
		{
			status = LOSE;
		}
	}
	
	public void checkGame()
	{
		if ( board.isGameLose() )
		{
			loseGame();
		}
		else
		if ( board.isGameWin() )
		{
			winGame();
		}
	}
	
	private void stopChronometer()
	{
		chronometer.stop();
	}
	
	public Board getBoard()
	{
		return board;
	}
	
	public void setBoard( Board newBoard )
	{
		board = newBoard;
	}

	public Chronometer getChronometer()
	{
		return chronometer;
	}

	public int getStatus()
	{
		return status;
	}
}
