package com.jmines.core;
import java.awt.*;
import java.awt.image.*;
import java.io.*;
import java.util.Properties;

import javax.imageio.*;
import javax.swing.*;

public class CellSkin
{
	private String filename;
	private String version;
	private String name;
	private String description;
	private int imageSize = 0;
	
	public static final int COVER = 0,
							MOUSE_OVER = 1,
							PRESSED = 2,
							NEIBORHOOD_MINES[] = { 3, 4, 5, 6, 7, 8, 9, 10, 11 },
							MINE_MARK = 12,
							QUESTION_MARK = 13,
							MINE = 14,
							EXPLOSION = 15,
							MARK_ERROR = 16;

	private BufferedImage[] image = new BufferedImage[17];	
	private BufferedImage bufferedImage;

	private boolean valid = false;  

	
	public CellSkin( String fn, InputStream imageStream, InputStream propertiesStream )
	{
		filename = fn;
		loadProperties( propertiesStream );
		
		valid = version.equals( "1.0" )
				  && name != null
				  && description != null;
				  
		if ( valid )
		{
			loadImage( imageStream );
		}
		else
		{
			System.err.println( "Error: " + filename + " is not a valid cell skin" );
		}
	}
	
	public String toString()
	{
		return getName();
	}
	
	private void loadProperties( InputStream propertiesStream )
	{
		Properties properties = new Properties();
		try
		{
			properties.load( propertiesStream );
			version 	= properties.getProperty( "version" );
			name 		= properties.getProperty( "name" );
			description	= properties.getProperty( "description" );
		}
		catch (IOException e)
		{
			valid = false;
			e.printStackTrace();
		}
	}
	
	private void loadImage( InputStream imageStream )
	{
		try
		{
			bufferedImage = ImageIO.read( imageStream );
			imageSize = bufferedImage.getHeight();
		
			for ( int i = 0; i < image.length; ++i )
			{
				image[i] = bufferedImage.getSubimage( i * imageSize, 0, imageSize, imageSize );
			}
		}
		catch ( IOException e )
		{
			valid = false;
			e.printStackTrace();
		}  
	}
	
	public Image getImage( int i ) throws IllegalStateException
	{
		if ( valid )
		{
			return image[i];
		}
		else
		{
			throw new IllegalStateException();
		}
	}
	
	public ImageIcon getSkin() throws IllegalStateException
	{
		if ( valid )
		{
			return new ImageIcon( bufferedImage );
		}
		else
		{
			throw new IllegalStateException();
		}
	}

	public String getFilename()
	{
		return filename;
	}

	public String getVersion()
	{
		return version;
	}

	public String getName()
	{
		return name;
	}

	public String getDescription()
	{
		return description;
	}

	public int getImageSize()
	{
		return imageSize;
	}

	public boolean isValid()
	{
		return valid;
	}
}
