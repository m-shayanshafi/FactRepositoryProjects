package com.jmines.gui;

import java.awt.event.*;
import java.util.Stack;

import javax.swing.*;
import javax.swing.border.BevelBorder;

import com.jgoodies.forms.layout.*;

import com.jmines.core.*;

public class StatusBar extends JPanel
{
	private JMines jMines;
	
	private Timer timer;
	private ActionListener timerTask;
	private static final int DELAY = 100; 
	
	private Stack infos;
	
	//GUI
	
	private JTextField infoField;
	private JTextField mineCountField;
	private JTextField timerField;
	private JButton newGameButton;
	
	
	public StatusBar( JMines jm )
	{
		super();
		
		jMines = jm;
		
		timerTask = new ActionListener()
		{
			public void actionPerformed( ActionEvent e )
			{
				updateTimerText();
			}
		};

		timer = new Timer( DELAY, timerTask );
		timer.start();
		
		infos = new Stack();
		
		initGUI();
	}
	
	private void initGUI()
	{
		FormLayout layout = new FormLayout( "fill:0:grow, 30dlu, 30dlu, pref", "pref" );
		CellConstraints cc = new CellConstraints();
		
		setLayout( layout );
		
		infoField = new JTextField();
		setJTextField( infoField );
		
		mineCountField = new JTextField();
		setJTextField( mineCountField );

		timerField = new JTextField();
		setJTextField( timerField );
		
		newGameButton = new JButton( "New" );
		newGameButton.addActionListener( new ActionListener()
		{
			public void actionPerformed( ActionEvent e )
			{
				jMines.newGame();
			}
		});


		add( infoField, 	 cc.xy( 1, 1 ) );
		add( mineCountField, cc.xy( 2, 1 ) );
		add( timerField,	 cc.xy( 3, 1 ) );
		add( newGameButton,  cc.xy( 4, 1 ) ); 
	}
	
	private void setJTextField( JTextField textField )
	{
		textField.setEditable( false );
		textField.setFocusable( false );
		textField.setBorder( BorderFactory.createBevelBorder( BevelBorder.LOWERED ) );
	}
	
	public void reset()
	{
		resetInfo();		
		update();
		timer.restart();
	}
	
	public void update()
	{
		mineCountField.setText( Cell.getMineMarkCount() + "/"
			+ jMines.getGame().getBoard().getSelectedTemplate().getMinesCount() );
		
		updateInfo();
	}
	
	private void updateInfo()
	{
		String str;
		if ( infos.empty() )
		{
			str = "";
		}
		else
		{
			str = ( String )infos.peek();
		}
		
		infoField.setText( str );
	}
	
	private void updateTimerText()
	{
		long time = jMines.getGame().getChronometer().getTime() / 100; 
		timerField.setText( Long.toString( time / 10 ) + "." + Long.toString( time % 10 ) );
	}
	
	public void pushInfo( String str )
	{
		infos.push( str );
		updateInfo();
	}
	
	public void popInfo()
	{
		infos.pop();
		updateInfo();
	}
	
	public void resetInfo()
	{
		infos.clear();
		updateInfo();
	}
}
