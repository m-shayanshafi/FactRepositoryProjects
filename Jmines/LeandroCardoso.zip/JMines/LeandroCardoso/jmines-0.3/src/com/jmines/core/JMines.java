package com.jmines.core;

import java.awt.*;
import java.awt.event.*;
import java.io.*;

import javax.swing.*;
import javax.swing.UIManager.LookAndFeelInfo;

import com.jmines.gui.*;
import com.jmines.util.*;
import com.jmines.util.Properties;


public class JMines extends JFrame
{
	private Game game;
	private GameHandler gameHandler;
	private SystemImage systemImage;
	private Properties properties;
	
	//GUI

	private CustomGUI customGUI;
	private RecordsGUI recordsGUI;
	//private OptionsGUI optionsGUI;
	private AboutGUI aboutGUI;
	
	private MenuHandler menuHandler;
	
	private Container container;
	
	private StatusBar statusBar;
	
	private ButtonGroup buttonGroup;
	private JMenuBar menuBar;
	private JMenu gameMenu;
	private JMenuItem newMenuItem;
	private JMenuItem recordsMenuItem;
	private JMenuItem exitMenuItem;
	private JMenu optionsMenu;
	private JRadioButtonMenuItem beginnerMenuItem;
	private JRadioButtonMenuItem intermediateMenuItem;
	private JRadioButtonMenuItem expertMenuItem;
	private JRadioButtonMenuItem professionalMenuItem;
	private JRadioButtonMenuItem masterMenuItem;
	private JRadioButtonMenuItem customMenuItem;
	//private JMenuItem optionsMenuItem;
	private JMenu aboutMenu;
	private JMenuItem aboutMenuItem;
	
	
	public JMines()
	{
		super( "JMines" );
		
		properties = Properties.getInstance();		
		systemImage = SystemImage.getInstance();
		loadSkin();
		gameHandler = new GameHandler( this );
		Cell.setControl( gameHandler );
		
		game = new Game();
		initGUI();
		newGame( Game.LEVEL[ Integer.parseInt( properties.getProperty( "initialLevel" ) ) ] );
		selectButtonGroup();
		
		setIconImage( systemImage.getImage( SystemImage.ICON ) );
		setResizable( false );
		setDefaultCloseOperation( EXIT_ON_CLOSE );

		centerLocation( true );
		setVisible( true );
	}

	public void newGame()
	{
		game.newGame();
		
		pack();
		statusBar.reset();
	}
	
	public void newGame( int level )
	{
		game.newGame( level );
		
		pack();
		centerLocation( false );
		statusBar.reset();
	}
	
	public void checkStatus()
	{
		switch ( game.getStatus() )
		{
			case Game.WIN:
				statusBar.pushInfo( "You Win!" );
				break;
			
			case Game.LOSE:
				statusBar.pushInfo( "You Lose!" );
		}
	}
	
	public StatusBar getStatusBar()
	{
		return statusBar;
	}
	
	public void selectButtonGroup()
	{
		ButtonModel bm;
			
		switch ( game.getBoard().getSelectedTemplateIndex() )
		{
			case 1:
				bm = beginnerMenuItem.getModel();
				break;
				
			case 2:
				bm = intermediateMenuItem.getModel();
				break;
					
			case 3:
				bm = expertMenuItem.getModel();
				break;
					
			case 4:
				bm = professionalMenuItem.getModel();
				break;
					
			case 5:
				bm = masterMenuItem.getModel();
				break;
					
			case Game.CUSTOM:
			default:
				bm = customMenuItem.getModel();
				break;
		}
		
		if ( buttonGroup.getSelection() != bm )
		{
			buttonGroup.setSelected( bm ,true ); 
		}
	}

	public Game getGame()
	{
		return game;
	}
	
	public GameHandler getGameHandler()
	{
		return gameHandler;
	}

	
	
	//GUI
	
	
	private void initGUI()
	{
		menuHandler = new MenuHandler();

		customGUI = new CustomGUI( this );
		recordsGUI = new RecordsGUI( this );
		//optionsGUI = new OptionsGUI( this );
		aboutGUI = new AboutGUI( this );

		statusBar = new StatusBar( this );
		
		container = getContentPane();
		container.setLayout( new BorderLayout() );
		setJMenuBar( getmenuBar() );
		
		container.add( game.getBoard(), BorderLayout.CENTER );
		container.add( statusBar, BorderLayout.SOUTH );
	}

	private JMenuBar getmenuBar()
	{
		//game
		
		newMenuItem = new JMenuItem( "New", KeyEvent.VK_N );
		newMenuItem.addActionListener( menuHandler );
		newMenuItem.setActionCommand( MenuHandler.NEW_GAME );
		newMenuItem.setAccelerator(
			KeyStroke.getKeyStroke(
				KeyEvent.VK_F2, 0, true
		));
		
		recordsMenuItem = new JMenuItem( "Records...", KeyEvent.VK_R );
		recordsMenuItem.addActionListener( menuHandler );
		recordsMenuItem.setActionCommand( MenuHandler.RECORDS );

		exitMenuItem = new JMenuItem( "Exit", KeyEvent.VK_X );
		exitMenuItem.addActionListener( menuHandler );
		exitMenuItem.setActionCommand( MenuHandler.EXIT );
		
		gameMenu = new JMenu( "Game" );
		gameMenu.setMnemonic( KeyEvent.VK_G );
		gameMenu.add( newMenuItem );
		gameMenu.addSeparator();
		gameMenu.add( recordsMenuItem );
		gameMenu.addSeparator();
		gameMenu.add( exitMenuItem );
		
		//options
		
		beginnerMenuItem = new JRadioButtonMenuItem( "Beginner" );
		beginnerMenuItem.setMnemonic( KeyEvent.VK_B );
		beginnerMenuItem.addActionListener( menuHandler );
		beginnerMenuItem.setActionCommand( MenuHandler.LEVEL0 );

		intermediateMenuItem = new JRadioButtonMenuItem( "Intermediate" );
		intermediateMenuItem.setMnemonic( KeyEvent.VK_I );
		intermediateMenuItem.addActionListener( menuHandler );
		intermediateMenuItem.setActionCommand( MenuHandler.LEVEL1 );

		expertMenuItem = new JRadioButtonMenuItem( "Expert" );
		expertMenuItem.setMnemonic( KeyEvent.VK_E );
		expertMenuItem.addActionListener( menuHandler );
		expertMenuItem.setActionCommand( MenuHandler.LEVEL2 );
		
		professionalMenuItem = new JRadioButtonMenuItem( "Professional" );
		professionalMenuItem.setMnemonic( KeyEvent.VK_P );
		professionalMenuItem.addActionListener( menuHandler );
		professionalMenuItem.setActionCommand( MenuHandler.LEVEL3 );
		
		masterMenuItem = new JRadioButtonMenuItem( "Master" );
		masterMenuItem.setMnemonic( KeyEvent.VK_M );
		masterMenuItem.addActionListener( menuHandler );
		masterMenuItem.setActionCommand( MenuHandler.LEVEL4 );
		
		customMenuItem = new JRadioButtonMenuItem( "Custom..." );
		customMenuItem.setMnemonic( KeyEvent.VK_C );
		customMenuItem.addActionListener( menuHandler );
		customMenuItem.setActionCommand( MenuHandler.CUSTOM_LEVEL );

		//optionsMenuItem = new JMenuItem( "Options...", KeyEvent.VK_O );
		//optionsMenuItem.addActionListener( menuHandler );
		//optionsMenuItem.setActionCommand( MenuHandler.OPTIONS );
		
		optionsMenu = new JMenu( "Options" );
		optionsMenu.setMnemonic( KeyEvent.VK_O );
		optionsMenu.add( beginnerMenuItem );
		optionsMenu.add( intermediateMenuItem );
		optionsMenu.add( expertMenuItem );
		optionsMenu.add( professionalMenuItem );
		optionsMenu.add( masterMenuItem );
		optionsMenu.add( customMenuItem );
		//optionsMenu.addSeparator();
		//optionsMenu.add( optionsMenuItem );

		//about
		
		aboutMenuItem = new JMenuItem( "About", KeyEvent.VK_A );
		aboutMenuItem.addActionListener( menuHandler );
		aboutMenuItem.setActionCommand( MenuHandler.ABOUT );

		aboutMenu = new JMenu( "About" );
		aboutMenu.setMnemonic( KeyEvent.VK_A );
		aboutMenu.add( aboutMenuItem );
		
		//menu
		
		menuBar = new JMenuBar();
		menuBar.add( gameMenu );
		menuBar.add( optionsMenu );
		menuBar.add( aboutMenu );
		
		buttonGroup = new ButtonGroup();
		buttonGroup.add( beginnerMenuItem );
		buttonGroup.add( intermediateMenuItem );
		buttonGroup.add( expertMenuItem );
		buttonGroup.add( professionalMenuItem );
		buttonGroup.add( masterMenuItem );
		buttonGroup.add( customMenuItem );
		
		return menuBar;
	}
	
	private void centerLocation( boolean force )
	{
		Rectangle rect = getGraphicsConfiguration().getBounds();
		int screenWidth = rect.width;
		int screenHeight = rect.height;
		
		if ( force || !rect.contains( getBounds() ) )
			setLocation( ( screenWidth - getWidth() ) /2, ( screenHeight - getHeight() ) /2 );
	}
	
	private static void initProperties()
	{
		Properties properties = Properties.getInstance();
		properties.setFilename( "jmines.cfg" );
		properties.load();
	}
	
	public static void loadSkin()
	{
		Properties properties = Properties.getInstance();
		String skin = properties.getProperty( "skin" );
		
		if ( skin.equals( "0" ) )
		{
			skin = "jmines";
		}
		
		try
		{
			Cell.setSkin( new CellSkin( skin,
				new BufferedInputStream( new FileInputStream( "skin" + File.separator + skin + ".gif" ) ),
				new BufferedInputStream( new FileInputStream( "skin" + File.separator + skin + ".txt" ) ) ) );
		}
		catch ( FileNotFoundException e )
		{
			System.err.println( "Error: skin " + skin + " not found" );
			e.printStackTrace();
		}
	}
	
	public static void loadLookAndFeel()
	{
		Properties properties = Properties.getInstance();
		
		try
		{
			String laf = properties.getProperty( "lookAndFeel" );
			
			if ( laf.equals( "0" ) )
			{
				LookAndFeelInfo[] lafi = UIManager.getInstalledLookAndFeels();
				for ( int i = 0; i < lafi.length; ++i )
				{
					System.out.println( lafi[i].getClassName() );
				}
				System.exit( 1 );
			}
			else
			if ( laf.equals( "1" ) )
			{
				laf = UIManager.getCrossPlatformLookAndFeelClassName();
			}
			else
			if ( laf.equals( "2" ) )
			{
				laf = UIManager.getSystemLookAndFeelClassName();
			}
			
			UIManager.setLookAndFeel( laf );
		}
		catch ( IllegalAccessException e )
		{
			e.printStackTrace();
		}
		catch ( InstantiationException e )
		{
			e.printStackTrace();
		}
		catch ( UnsupportedLookAndFeelException e )
		{
			System.err.println( "Error: Unsuported Look and Feel" );
			e.printStackTrace();
		}
		catch ( ClassNotFoundException e )
		{
			System.err.println( "Error: Look and feel " + properties.getProperty( "lookAndFeel" ) + " not found" );
			e.printStackTrace();
		}
	}
	
	
	
	public static void main(String[] args)
	{
		Chronometer chronometer = new Chronometer();
		chronometer.start();
		System.out.print( "Starting JMines v0.3... " );
		
		initProperties();
		loadLookAndFeel();
		JMines jMines = new JMines();
		
		chronometer.stop();
		long time = chronometer.getTime() / 100;
		System.out.println( time / 10 + "." + time % 10 + "s");
	}
	
	
	
	private class MenuHandler implements ActionListener
	{
		public static final String NEW_GAME = "new",
									LEVEL0 = "l0",
									LEVEL1 = "l1",
									LEVEL2 = "l2",
									LEVEL3 = "l3",
									LEVEL4 = "l4",
									CUSTOM_LEVEL = "custom",
									RECORDS = "records",
									EXIT = "exit",
									OPTIONS = "options",
									ABOUT = "about";
		
		public void actionPerformed( ActionEvent e )
		{
			if ( e.getActionCommand() == NEW_GAME )
			{
				newGame();
			}
			else
			if ( e.getActionCommand() == LEVEL0 )
			{
				newGame( Game.LEVEL[0] );
			}
			else
			if ( e.getActionCommand() == LEVEL1 )
			{
				newGame( Game.LEVEL[1] );
			}
			else
			if ( e.getActionCommand() == LEVEL2 )
			{
				newGame( Game.LEVEL[2] );
			}
			else
			if ( e.getActionCommand() == LEVEL3 )
			{
				newGame( Game.LEVEL[3] );
			}
			else
			if ( e.getActionCommand() == LEVEL4 )
			{
				newGame( Game.LEVEL[4] );
			}
			else
			if ( e.getActionCommand() == CUSTOM_LEVEL )
			{
				customGUI.show();
				setEnabled( false );
			}
			else
			if ( e.getActionCommand() == RECORDS )
			{
				recordsGUI.show();
				setEnabled( false );
			}
			else
			if ( e.getActionCommand() == EXIT )
			{
				System.exit( 0 );
			}
			else
			if ( e.getActionCommand() == OPTIONS )
			{
				//optionsGUI.show();
				//setEnabled( false );
			}
			else
			if ( e.getActionCommand() == ABOUT )
			{
				aboutGUI.show();
				setEnabled( false );
			}
		}		
	}
	
	
}
