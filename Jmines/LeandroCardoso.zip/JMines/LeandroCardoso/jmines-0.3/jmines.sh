java -jar jmines.jar
