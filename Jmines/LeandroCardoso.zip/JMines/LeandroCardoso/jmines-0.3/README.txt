JMines - The Java minesweeper game
Version 0.3
by Leandro Cardoso, copyright 2004
hosted by sourceforge

This software is distributed under the terms of the GNU General Public License (GPL). See License.txt

This software is a alpha version. It has been in constant evolution.
Visit http://www.sourceforge.net/jmines for the new version

Send comments, bugs, syggestions for maverick_br@sourceforge.net. Your email is welcome

This software includes software developed by JGoodies Karsten Lentzsch. http://www.jgoodies.com

This software requires a JRE1.4 visit http://java.sun.com for download the last version or use your favorite JRE.

For the new features see history.txt
For configure your JMines see jmines.cfg
For run JMines
	Windows execute "jmines.bat" in jmines directory
	Linux execute "./jmines.sh" in jmines directory
	Any OS execute "java -jar jmines.jar" in jmines directory
