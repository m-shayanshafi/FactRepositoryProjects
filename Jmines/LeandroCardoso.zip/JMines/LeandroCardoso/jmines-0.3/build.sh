cd bin/
jar cvfm jmines.jar ../MANIFEST.MF .
mv jmines.jar ..
