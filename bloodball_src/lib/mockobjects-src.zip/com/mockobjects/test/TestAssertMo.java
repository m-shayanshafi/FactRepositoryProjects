package com.mockobjects.test;

import java.util.Vector;
import junit.framework.*;
import com.mockobjects.*;
import com.mockobjects.util.*;

public class TestAssertMo extends TestCaseMo {
    private static final Class THIS = TestAssertMo.class;

    public TestAssertMo(String name) {
        super(name);
    }

    public static void main(String[] args) {
        start(new String[] { THIS.getName()});
    }

    public static Test suite() {
        return new TestSuite(THIS);
    }

    public void testAssertExcludes() {
        AssertMo.assertExcludes(
            "Should not include substring",
            "dog",
            "The quick brown fox");
    }

    public void testAssertExcludesFails() {
        Throwable result = null;
        try {
            AssertMo.assertExcludes(
                "Should fail on exclude",
                "fox",
                "The quick brown fox");
        } catch (AssertionFailedError ex) {
            result = ex;
        }

        assertTrue("Should get an exception", result != null);

    }

    public void testAssertIncludes() {
        AssertMo.assertIncludes(
            "Should include a substring",
            "fox",
            "The quick brown fox");
    }

    public void testAssertIncludesFails() {
        Throwable result = null;
        try {
            AssertMo.assertIncludes(
                "Should fail if no include",
                "dog",
                "The quick brown fox");
        } catch (AssertionFailedError ex) {
            result = ex;
        }

        assertTrue("Should get an exception", result != null);

    }

    public void testAssertStartsWith() {
        AssertMo.assertStartsWith(
            "Should start with fox",
            "fox",
            "fox quick brown");
    }

    public void testAssertStartsWithFails() {
        Throwable result = null;
        try {
            AssertMo.assertStartsWith(
                "Should fail if it doesn't start with fox",
                "fox",
                "The quick brown fox");
        } catch (AssertionFailedError ex) {
            result = ex;
        }

        assertTrue("Should get an exception", result != null);

    }

    public void testDifferentArrays() {
        Object[] anExpectedArray = new Object[] { "one", new Integer(2)};
        Object[] anActualArray = new Object[] { "two", new Integer(2)};

        boolean threwException = false;
        try {
            AssertMo.assertEquals(
                "Should be expected value",
                anExpectedArray,
                anActualArray);
        } catch (AssertionFailedError ignoredException) {
            threwException = true;
        }
        assertTrue("should have thrown assertion failure", threwException);
    }

    public void testDifferentLengthArrays() {
        Object[] anExpectedArray = new Object[] { "one", new Integer(2)};
        Object[] anActualArray = new Object[] { "one" };

        boolean threwException = false;
        try {
            AssertMo.assertEquals(
                "Should be expected value",
                anExpectedArray,
                anActualArray);
        } catch (AssertionFailedError ignoredException) {
            threwException = true;
        }
        assertTrue("should have thrown assertion failure", threwException);
    }

    public void testDifferentObjectArrays() {
        Object[] anExpectedArray = new Object[] { "one", new Integer(2)};
        Object[] anActualArray = new Object[] { new Integer(2), new Vector()};

        boolean threwException = false;
        try {
            AssertMo.assertEquals(
                "Should be expected value",
                anExpectedArray,
                anActualArray);
        } catch (AssertionFailedError ignoredException) {
            threwException = true;
        }
        assertTrue("should have thrown assertion failure", threwException);
    }

    public void testEqualArrays() {
        Object[] anExpectedArray = new Object[] { "one", new Integer(2)};
        Object[] anActualArray = new Object[] { "one", new Integer(2)};

        AssertMo.assertEquals(
            "Should be expected value",
            anExpectedArray,
            anActualArray);
    }

    public void testEqualEmptyArrays() {
        Object[] anExpectedArray = new Object[0];
        Object[] anActualArray = new Object[0];

        AssertMo.assertEquals(
            "Should be expected value",
            anExpectedArray,
            anActualArray);
    }
}
