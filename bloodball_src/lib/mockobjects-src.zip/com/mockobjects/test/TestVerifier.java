package com.mockobjects.test;
import java.io.*;
import java.util.*;
import junit.framework.*;
import com.mockobjects.*;

import com.mockobjects.util.*;public class TestVerifier extends TestCaseMo {
    private static final Class THIS = TestVerifier.class;class OneVerifiable extends MockObject {
        private ExpectationValue myValue = new ExpectationValue("should fail");
        private int anotherField;

        public OneVerifiable() {
            myValue.setFailOnVerify();
            myValue.setExpected("good");
        }
        public void setValue(String aValue) {
            myValue.setActual(aValue);
        }
    }class InheritVerifiable extends OneVerifiable {
    }



    public TestVerifier(String name) {
        super(name);
    }



    public static void main(String[] args) {
        start(new String[] { THIS.getName()});
    }



    public static Test suite() {
        return new TestSuite(THIS);
    }



    public void testInheritVerifiableFails() {
        InheritVerifiable inheritVerifiable = new InheritVerifiable();
        inheritVerifiable.setValue("bad");

        boolean hasThrownException = false;
        try {
            inheritVerifiable.verify();
        } catch (AssertionFailedError ex) {
            hasThrownException = true;
        }
        assertTrue("Should have thrown exception", hasThrownException);
    }



    public void testInheritVerifiablePasses() {
        InheritVerifiable inheritVerifiable = new InheritVerifiable();
        inheritVerifiable.setValue("good");

        inheritVerifiable.verify();
    }



    public void testNoVerifiables() {
        class NoVerifiables extends MockObject {
        }

        new NoVerifiables().verify();
    }



    public void testOneVerifiableFails() {
        OneVerifiable oneVerifiable = new OneVerifiable();
        oneVerifiable.setValue("bad");

        boolean hasThrownException = false;
        try {
            oneVerifiable.verify();
        } catch (AssertionFailedError ex) {
            hasThrownException = true;
        }
        assertTrue("Should have thrown exception", hasThrownException);
    }



    public void testOneVerifiablePasses() {
        OneVerifiable oneVerifiable = new OneVerifiable();
        oneVerifiable.setValue("good");

        oneVerifiable.verify();
    }
}
