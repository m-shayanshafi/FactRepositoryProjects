package com.mockobjects.test;

import java.util.*;
import junit.framework.*;
import com.mockobjects.*;
import com.mockobjects.util.*;

/**
 * JUnit test case for TestMapEntry
 */

public class TestMapEntry extends TestCaseMo {

    public TestMapEntry(String name) {
        super(name);
    }

    public static void main(String[] args) {
        start(new String[] { TestMapEntry.class.getName()});
    }

    public static Test suite() {
        return new TestSuite(TestMapEntry.class);
    }

    public void testEquals() {
        assertEquals(
            "Should be expected value",
            new MapEntry("A", "2"),
            new MapEntry("A", "2"));
        assertTrue(
            "Should not be equal",
            !new MapEntry("A", "2").equals(new MapEntry("A", "1")));
        assertTrue(
            "Should not be equal",
            !new MapEntry("A", "2").equals(new MapEntry("B", "2")));
        assertEquals(
            "Should be equal with null value",
            new MapEntry("A", null),
            new MapEntry("A", null));
        assertEquals(
            "Should be equal with null key",
            new MapEntry(null, "A"),
            new MapEntry(null, "A"));
    }
}
