package com.mockobjects;

import java.util.*;

public interface ExpectationCollection extends Expectation {

    void addActual(Object actual);

    void addActualMany(Object[] actuals);

    void addActualMany(Enumeration actuals);

    void addActualMany(Iterator actuals);

    void addExpected(Object expected);

    void addExpectedMany(Object[] expectedItems);

    void addExpectedMany(Enumeration expectedItems);

    void addExpectedMany(Iterator expectedItems);
}
