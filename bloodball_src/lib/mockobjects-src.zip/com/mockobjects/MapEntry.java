package com.mockobjects;

import java.util.*;

import com.mockobjects.util.Null;

/**
 * A public MapEntry data type that can be used where the Map.Entry interface is required
 * (needed because the Sun implementation is package protected)
 */

public class MapEntry implements Map.Entry {
    private Object myKey;
    private Object myValue;

    public MapEntry(Object aKey, Object aValue) {
        super();
        myKey = (aKey == null ? new Null() : aKey);
        myValue = (aValue == null ? new Null() : aValue);
    }

    public boolean equals(Object o) {
        if (!(o instanceof MapEntry)) {
            return false;
        }
        MapEntry other = (MapEntry) o;
        return myKey.equals(other.getKey()) && myValue.equals(other.getValue());
    }

    public Object getKey() {
        return myKey;
    }

    public Object getValue() {
        return myValue;
    }

    public int hashCode() {
        return myKey.hashCode() ^ myValue.hashCode();
    }

    public Object setValue(Object aValue) {
        Object oldValue = myValue;
        myValue = (null == aValue ? new Null() : aValue);
        return oldValue;
    }

    public String toString() {
        return myKey.toString() + "=" + myValue.toString();
    }
}
