package com.mockobjects.servlet;

import java.util.*;
import javax.servlet.http.*;
import com.mockobjects.*;

public class MockHttpServletRequest implements HttpServletRequest {
    private Dictionary myParameters = new Hashtable();

    private String myPathInfo;

    public MockHttpServletRequest() {
        super();
    }

    /**
     * @deprecated
     */
    public void addActualParameter(String paramName, String[] values) {
        setupAddParameter(paramName, values);
    }

    /**
     * @deprecated
     */
    public void addActualParameter(String paramName, String value) {
        setupAddParameter(paramName, value);
    }

    /**
     * getAttribute method comment.
     */
    public Object getAttribute(String arg1) {
        return null;
    }

    /**
     * getAttributeNames method comment.
     */
    public java.util.Enumeration getAttributeNames() {
        return null;
    }

    /**
     * getAuthType method comment.
     */
    public String getAuthType() {
        return null;
    }

    /**
     * getCharacterEncoding method comment.
     */
    public String getCharacterEncoding() {
        return null;
    }

    /**
     * getContentLength method comment.
     */
    public int getContentLength() {
        return 0;
    }

    /**
     * getContentType method comment.
     */
    public String getContentType() {
        return null;
    }

    /**
     * getContextPath method comment.
     */
    public java.lang.String getContextPath() {
        return null;
    }

    /**
     * getCookies method comment.
     */
    public javax.servlet.http.Cookie[] getCookies() {
        return null;
    }

    /**
     * getDateHeader method comment.
     */
    public long getDateHeader(String arg1) {
        return 0;
    }

    /**
     * getHeader method comment.
     */
    public String getHeader(String arg1) {
        return null;
    }

    /**
     * getHeaderNames method comment.
     */
    public java.util.Enumeration getHeaderNames() {
        return null;
    }

    /**
     * getHeaders method comment.
     */
    public java.util.Enumeration getHeaders(java.lang.String arg1) {
        return null;
    }

    /**
     * getInputStream method comment.
     */
    public javax.servlet.ServletInputStream getInputStream()
        throws java.io.IOException {
        return null;
    }

    /**
     * getIntHeader method comment.
     */
    public int getIntHeader(String arg1) {
        return 0;
    }

    /**
     * getLocale method comment.
     */
    public java.util.Locale getLocale() {
        return null;
    }

    /**
     * getLocales method comment.
     */
    public java.util.Enumeration getLocales() {
        return null;
    }

    /**
     * getMethod method comment.
     */
    public String getMethod() {
        return null;
    }

    public String getParameter(String paramName) {
        String[] values = getParameterValues(paramName);
        return (values == null ? null : values[0]);
    }

    public java.util.Enumeration getParameterNames() {
        return myParameters.keys();
    }

    public String[] getParameterValues(String key) {
        return (String[]) myParameters.get(key);
    }

    public String getPathInfo() {
        return myPathInfo;
    }

    /**
     * getPathTranslated method comment.
     */
    public String getPathTranslated() {
        return null;
    }

    /**
     * getProtocol method comment.
     */
    public String getProtocol() {
        return null;
    }

    /**
     * getQueryString method comment.
     */
    public String getQueryString() {
        return null;
    }

    /**
     * getReader method comment.
     */
    public java.io.BufferedReader getReader() throws java.io.IOException {
        return null;
    }

    /**
     * getRealPath method comment.
     */
    public String getRealPath(String arg1) {
        return null;
    }

    /**
     * getRemoteAddr method comment.
     */
    public String getRemoteAddr() {
        return null;
    }

    /**
     * getRemoteHost method comment.
     */
    public String getRemoteHost() {
        return null;
    }

    /**
     * getRemoteUser method comment.
     */
    public String getRemoteUser() {
        return null;
    }

    /**
     * getRequestDispatcher method comment.
     */
    public javax.servlet.RequestDispatcher getRequestDispatcher(
        java.lang.String arg1) {
        return null;
    }

    /**
     * getRequestedSessionId method comment.
     */
    public String getRequestedSessionId() {
        return null;
    }

    /**
     * getRequestURI method comment.
     */
    public String getRequestURI() {
        return null;
    }

    /**
     * getScheme method comment.
     */
    public String getScheme() {
        return null;
    }

    /**
     * getServerName method comment.
     */
    public String getServerName() {
        return null;
    }

    /**
     * getServerPort method comment.
     */
    public int getServerPort() {
        return 0;
    }

    /**
     * getServletPath method comment.
     */
    public String getServletPath() {
        return null;
    }

    /**
     * getSession method comment.
     */
    public javax.servlet.http.HttpSession getSession() {
        return null;
    }

    /**
     * getSession method comment.
     */
    public javax.servlet.http.HttpSession getSession(boolean arg1) {
        return null;
    }

    /**
     * getUserPrincipal method comment.
     */
    public java.security.Principal getUserPrincipal() {
        return null;
    }

    /**
     * isRequestedSessionIdFromCookie method comment.
     */
    public boolean isRequestedSessionIdFromCookie() {
        return false;
    }

    /**
     * isRequestedSessionIdFromUrl method comment.
     */
    public boolean isRequestedSessionIdFromUrl() {
        return false;
    }

    /**
     * isRequestedSessionIdFromURL method comment.
     */
    public boolean isRequestedSessionIdFromURL() {
        return false;
    }

    /**
     * isRequestedSessionIdValid method comment.
     */
    public boolean isRequestedSessionIdValid() {
        return false;
    }

    /**
     * isSecure method comment.
     */
    public boolean isSecure() {
        return false;
    }

    /**
     * isUserInRole method comment.
     */
    public boolean isUserInRole(java.lang.String arg1) {
        return false;
    }

    /**
     * removeAttribute method comment.
     */
    public void removeAttribute(java.lang.String arg1) {
    }

    /**
     * setAttribute method comment.
     */
    public void setAttribute(String arg1, Object arg2) {
    }

    /**
     * @deprecated
     */
    public void setNoActualParameters() {
        setupNoParameters();
    }

    public void setupAddParameter(String paramName, String[] values) {
        myParameters.put(paramName, values);
    }

    public void setupAddParameter(String paramName, String value) {
        setupAddParameter(paramName, new String[] { value });
    }

    public void setupNoParameters() {
        myParameters = new Hashtable();
    }

    public void setupPathInfo(String pathInfo) {
        myPathInfo = pathInfo;
    }
}
