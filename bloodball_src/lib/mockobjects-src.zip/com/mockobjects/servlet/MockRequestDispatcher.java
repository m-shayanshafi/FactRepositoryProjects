package com.mockobjects.servlet;

import java.io.IOException;
import javax.servlet.*;

public class MockRequestDispatcher implements RequestDispatcher {

    /**

     * MockRequestDispatcher constructor comment.

     */

    public MockRequestDispatcher() {

        super();

    }

    public void forward(ServletRequest arg1, ServletResponse arg2)
        throws ServletException, IOException {
    }

    public void include(ServletRequest arg1, ServletResponse arg2)
        throws ServletException, IOException {
    }
}
