package com.mockobjects.sql;

import java.sql.*;
import java.sql.Date;
import java.util.*;
import java.math.BigDecimal;
import java.io.InputStream;
import java.io.Reader;

import junit.framework.Assert;
import junit.framework.AssertionFailedError;
import com.mockobjects.*;

/**
 * This is the base implementation of a mock result set.
 * It manages converting objects from the current row into a other types.
 * Entries can be found by either column index or column name.
 * For basic java types (e.g. int, boolean), insert an instance of
 * the appropriate object (e.g. Integer, Boolean)
 * It also counts close() and next() calls
 * To force throwing a SQLException on a getter, set the corresponding value to be of type SQLException.
 */
abstract public class MockResultSet extends MockObject implements ResultSet {
    private ExpectationCounter myCloseCalls = new ExpectationCounter("MockResultSet.close");
    protected ExpectationCounter myNextCalls = new ExpectationCounter("MockResultSet.next");

    private ResultSetMetaData myMetaData;
    private Statement myStatement;

    public MockResultSet() {
        super();
    }

    /**
     * Used as the base implementation for getting all types of object,
     * based on 1-based column index
     * @see java.sql.ResultSet#getObject(int)
     */
    abstract public Object getObject(int columnIndex) throws SQLException;

    /**
     * Used as the base implementation for getting all types of object,
     * based on columnName
     * @see java.sql.ResultSet#getObject(int)
     */
    abstract public Object getObject(String columnName) throws SQLException;

    abstract public boolean next() throws SQLException;

    abstract public int getRow() throws SQLException;

    public void setExpectedCloseCalls(int calls) {
        myCloseCalls.setExpected(calls);
    }

    public void setExpectedNextCalls(int calls) {
        myNextCalls.setExpected(calls);
    }

    public void setupMetaData(ResultSetMetaData metaData) {
        myMetaData = metaData;
    }

    public void setupStatement(Statement statement) {
        myStatement = statement;
    }

    public void close() throws SQLException {
        myCloseCalls.inc();
    }

    public Array getArray(int i) throws SQLException {
        return (Array)getObject(i);
    }

    public Array getArray(String colName) throws SQLException {
        return (Array)getObject(colName);
    }

    public InputStream getAsciiStream(int columnIndex) throws SQLException {
        return (InputStream)getObject(columnIndex);
    }

    public InputStream getAsciiStream(String columnName) throws SQLException {
        return (InputStream)getObject(columnName);
    }

    public BigDecimal getBigDecimal(String columnName, int scale) throws SQLException {
        return getBigDecimal(columnName);
    }

    public BigDecimal getBigDecimal(int columnIndex) throws SQLException {
        return (BigDecimal)getObject(columnIndex);
    }

    public BigDecimal getBigDecimal(int columnIndex, int scale) throws SQLException {
        return (BigDecimal)getObject(columnIndex);
    }

    public BigDecimal getBigDecimal(String columnName) throws SQLException {
        return (BigDecimal)getObject(columnName);
    }

    public InputStream getBinaryStream(int columnIndex) throws SQLException {
        return (InputStream)getObject(columnIndex);
    }

    public InputStream getBinaryStream(String columnName) throws SQLException {
        return (InputStream)getObject(columnName);
    }

    public Blob getBlob(int i) throws SQLException {
        return (Blob)getObject(i);
    }

    public Blob getBlob(String colName) throws SQLException {
        return (Blob)getObject(colName);
    }

    public boolean getBoolean(int columnIndex) throws SQLException {
        return ((Boolean)getObject(columnIndex)).booleanValue();
    }

    public boolean getBoolean(String columnName) throws SQLException {
        return ((Boolean)getObject(columnName)).booleanValue();
    }

    public byte getByte(int columnIndex) throws SQLException {
        return ((Byte)getObject(columnIndex)).byteValue();
    }

    public byte getByte(String columnName) throws SQLException {
        return ((Byte)getObject(columnName)).byteValue();
    }

    public byte[] getBytes(int columnIndex) throws SQLException {
        return (byte[])getObject(columnIndex);
    }

    public byte[] getBytes(String columnName) throws SQLException {
        return (byte[])getObject(columnName);
    }

    public Reader getCharacterStream(int columnIndex) throws SQLException {
        return (Reader)getObject(columnIndex);
    }

    public Reader getCharacterStream(String columnName) throws SQLException {
        return (Reader)getObject(columnName);
    }

    public Clob getClob(int i) throws SQLException {
        return (Clob)getObject(i);
    }

    public Clob getClob(String colName) throws SQLException {
        return (Clob)getObject(colName);
    }

    public String getCursorName() throws SQLException {
        throw new AssertionFailedError("MockResultSet getCursorName not implemented");
    }

    public int getConcurrency() throws SQLException {
        throw new AssertionFailedError("MockResultSet getConcurrency not implemented");
    }

    public Date getDate(int columnIndex) throws SQLException {
        return (Date)getObject(columnIndex);
    }

    public Date getDate(String columnName) throws SQLException {
        return (Date)getObject(columnName);
    }

    public Date getDate(int columnIndex, Calendar cal) throws SQLException {
        return getDate(columnIndex);
    }

    public Date getDate(String columnName, Calendar cal) throws SQLException {
        return getDate(columnName);
    }

    public double getDouble(int columnIndex) throws SQLException {
        return ((Double)getObject(columnIndex)).doubleValue();
    }

    public double getDouble(String columnName) throws SQLException {
        return ((Double)getObject(columnName)).doubleValue();
    }

    public int getFetchDirection() throws SQLException {
        throw new AssertionFailedError("MockResultSet getFetchDirection not implemented");
    }

    public int getFetchSize() throws SQLException {
        throw new AssertionFailedError("MockResultSet getFetchSize not implemented");
    }

    public float getFloat(int columnIndex) throws SQLException {
        return ((Float)getObject(columnIndex)).floatValue();
    }

    public float getFloat(String columnName) throws SQLException {
        return ((Float)getObject(columnName)).floatValue();
    }

    public int getInt(int columnIndex) throws SQLException {
        return ((Integer) getObject(columnIndex)).intValue();
    }

    public int getInt(String columnName) throws SQLException {
        return ((Integer) getObject(columnName)).intValue();
    }

    public long getLong(int columnIndex) throws SQLException {
        return ((Long) getObject(columnIndex)).longValue();
    }

    public long getLong(String columnName) throws SQLException {
        return ((Long) getObject(columnName)).longValue();
    }

    public ResultSetMetaData getMetaData() throws SQLException {
        return myMetaData;
    }

    public Object getObject(int i, Map map) throws SQLException {
        throw new AssertionFailedError("MockResultSet getObject not implemented");
    }

    public Object getObject(String colName, Map map) throws SQLException {
        throw new AssertionFailedError("MockResultSet getObject not implemented");
    }

    public Ref getRef(int i) throws SQLException {
        return (Ref)getObject(i);
    }

    public Ref getRef(String colName) throws SQLException {
        return (Ref)getObject(colName);
    }

    public short getShort(String columnName) throws SQLException {
        return ((Short)getObject(columnName)).shortValue();
    }

    public short getShort(int columnIndex) throws SQLException {
        return ((Short)getObject(columnIndex)).shortValue();
    }

    public Statement getStatement() throws SQLException {
        return myStatement;
    }

    public String getString(int columnIndex) throws SQLException {
        return (String)getObject(columnIndex);
    }

    public String getString(String columnName) throws SQLException {
        return (String)getObject(columnName);
    }

    public Time getTime(int columnIndex) throws SQLException {
        return (Time)getObject(columnIndex);
    }

    public Time getTime(String columnName) throws SQLException {
        return (Time)getObject(columnName);
    }

    public Time getTime(int columnIndex, Calendar cal) throws SQLException {
        return getTime(columnIndex);
    }

    public Time getTime(String columnName, Calendar cal) throws SQLException {
        return getTime(columnName);
    }

    public Timestamp getTimestamp(int columnIndex) throws SQLException {
        return (Timestamp)getObject(columnIndex);
    }

    public Timestamp getTimestamp(String columnName) throws SQLException {
        return (Timestamp)getObject(columnName);
    }

    public Timestamp getTimestamp(int columnIndex, Calendar cal) throws SQLException {
        return getTimestamp(columnIndex);
    }

    public Timestamp getTimestamp(String columnName, Calendar cal) throws SQLException {
        return getTimestamp(columnName);
    }

    public int getType() throws SQLException {
        throw new AssertionFailedError("MockResultSet getType not implemented");
    }

    public InputStream getUnicodeStream(int columnIndex) throws SQLException {
        return (InputStream)getObject(columnIndex);
    }

    public InputStream getUnicodeStream(String columnName) throws SQLException {
        return (InputStream)getObject(columnName);
    }

    public SQLWarning getWarnings() throws SQLException {
        throw new AssertionFailedError("MockResultSet getWarnings not implemented");
    }

    public void clearWarnings() throws SQLException {
        throw new AssertionFailedError("MockResultSet clearWarnings not implemented");
    }

    public int findColumn(String columnName) throws SQLException {
        throw new AssertionFailedError("MockResultSet findColumn not implemented");
    }

    public boolean isBeforeFirst() throws SQLException {
        throw new AssertionFailedError("MockResultSet isBeforeFirst not implemented");
    }

    public boolean isAfterLast() throws SQLException {
        throw new AssertionFailedError("MockResultSet getFetchSize not implemented");
    }

    public boolean isFirst() throws SQLException {
        throw new AssertionFailedError("MockResultSet isFirst not implemented");
    }

    public boolean isLast() throws SQLException {
        throw new AssertionFailedError("MockResultSet isLast not implemented");
    }

    public void beforeFirst() throws SQLException {
        throw new AssertionFailedError("MockResultSet beforeFirst not implemented");
    }

    public void afterLast() throws SQLException {
        throw new AssertionFailedError("MockResultSet afterLast not implemented");
    }

    public boolean first() throws SQLException {
        throw new AssertionFailedError("MockResultSet first not implemented");
    }

    public boolean last() throws SQLException {
        throw new AssertionFailedError("MockResultSet last not implemented");
    }

    public boolean absolute(int row) throws SQLException {
        throw new AssertionFailedError("MockResultSet absolute not implemented");
    }

    public boolean relative(int rows) throws SQLException {
        throw new AssertionFailedError("MockResultSet relative not implemented");
    }

    public boolean previous() throws SQLException {
        throw new AssertionFailedError("MockResultSet previous not implemented");
    }

    public void setFetchDirection(int direction) throws SQLException {
        throw new AssertionFailedError("MockResultSet setFetchDirection not implemented");
    }

    public void setFetchSize(int rows) throws SQLException {
        throw new AssertionFailedError("MockResultSet setFetchSize not implemented");
    }

    public boolean rowUpdated() throws SQLException {
        throw new AssertionFailedError("MockResultSet rowUpdated not implemented");
    }

    public boolean rowInserted() throws SQLException {
        throw new AssertionFailedError("MockResultSet rowInserted not implemented");
    }

    public boolean rowDeleted() throws SQLException {
        throw new AssertionFailedError("MockResultSet rowDeleted not implemented");
    }

    public void updateNull(int columnIndex) throws SQLException {
        throw new AssertionFailedError("MockResultSet updateNull not implemented");
    }

    public void updateBoolean(int columnIndex, boolean x) throws SQLException {
        throw new AssertionFailedError("MockResultSet updateBoolean not implemented");
    }

    public void updateByte(int columnIndex, byte x) throws SQLException {
        throw new AssertionFailedError("MockResultSet updateByte not implemented");
    }

    public void updateShort(int columnIndex, short x) throws SQLException {
        throw new AssertionFailedError("MockResultSet updateShort not implemented");
    }

    public void updateInt(int columnIndex, int x) throws SQLException {
        throw new AssertionFailedError("MockResultSet updateInt not implemented");
    }

    public void updateLong(int columnIndex, long x) throws SQLException {
        throw new AssertionFailedError("MockResultSet updateLong not implemented");
    }

    public void updateFloat(int columnIndex, float x) throws SQLException {
        throw new AssertionFailedError("MockResultSet updateFloat not implemented");
    }

    public void updateDouble(int columnIndex, double x) throws SQLException {
        throw new AssertionFailedError("MockResultSet updateDouble not implemented");
    }

    public void updateBigDecimal(int columnIndex, BigDecimal x) throws SQLException {
        throw new AssertionFailedError("MockResultSet updateBigDecimal not implemented");
    }

    public void updateString(int columnIndex, String x) throws SQLException {
        throw new AssertionFailedError("MockResultSet updateString not implemented");
    }

    public void updateBytes(int columnIndex, byte x[]) throws SQLException {
        throw new AssertionFailedError("MockResultSet updateBytes not implemented");
    }

    public void updateDate(int columnIndex, Date x) throws SQLException {
        throw new AssertionFailedError("MockResultSet updateDate not implemented");
    }

    public void updateTime(int columnIndex, Time x) throws SQLException {
        throw new AssertionFailedError("MockResultSet updateTime not implemented");
    }

    public void updateTimestamp(int columnIndex, Timestamp x)
            throws SQLException {
        throw new AssertionFailedError("MockResultSet updateTimestamp not implemented");
    }

    public void updateAsciiStream(int columnIndex,
                                  InputStream x,
                                  int length) throws SQLException {
        throw new AssertionFailedError("MockResultSet updateAsciiStream not implemented");
    }

    public void updateBinaryStream(int columnIndex,
                                   InputStream x,
                                   int length) throws SQLException {
        throw new AssertionFailedError("MockResultSet updateBinaryStream not implemented");
    }

    public void updateCharacterStream(int columnIndex,
                                      Reader x,
                                      int length) throws SQLException {
        throw new AssertionFailedError("MockResultSet updateCharacterStream not implemented");
    }

    public void updateObject(int columnIndex, Object x, int scale)
            throws SQLException {
        throw new AssertionFailedError("MockResultSet updateObject not implemented");
    }

    public void updateObject(int columnIndex, Object x) throws SQLException {
        throw new AssertionFailedError("MockResultSet updateObject not implemented");
    }

    public void updateNull(String columnName) throws SQLException {
        throw new AssertionFailedError("MockResultSet updateNull not implemented");
    }

    public void updateBoolean(String columnName, boolean x) throws SQLException {
        throw new AssertionFailedError("MockResultSet updateBoolean not implemented");
    }

    public void updateByte(String columnName, byte x) throws SQLException {
        throw new AssertionFailedError("MockResultSet updateByte not implemented");
    }

    public void updateShort(String columnName, short x) throws SQLException {
        throw new AssertionFailedError("MockResultSet updateShort not implemented");
    }

    public void updateInt(String columnName, int x) throws SQLException {
        throw new AssertionFailedError("MockResultSet updateInt not implemented");
    }

    public void updateLong(String columnName, long x) throws SQLException {
        throw new AssertionFailedError("MockResultSet updateLong not implemented");
    }

    public void updateFloat(String columnName, float x) throws SQLException {
        throw new AssertionFailedError("MockResultSet updateFloat not implemented");
    }

    public void updateDouble(String columnName, double x) throws SQLException {
        throw new AssertionFailedError("MockResultSet updateDouble not implemented");
    }

    public void updateBigDecimal(String columnName, BigDecimal x) throws SQLException {
        throw new AssertionFailedError("MockResultSet updateBigDecimal not implemented");
    }

    public void updateString(String columnName, String x) throws SQLException {
        throw new AssertionFailedError("MockResultSet updateString not implemented");
    }

    public void updateBytes(String columnName, byte x[]) throws SQLException {
        throw new AssertionFailedError("MockResultSet updateBytes not implemented");
    }

    public void updateDate(String columnName, Date x) throws SQLException {
        throw new AssertionFailedError("MockResultSet updateDate not implemented");
    }

    public void updateTime(String columnName, Time x) throws SQLException {
        throw new AssertionFailedError("MockResultSet updateTime not implemented");
    }

    public void updateTimestamp(String columnName, Timestamp x)
            throws SQLException {
        throw new AssertionFailedError("MockResultSet updateTimestamp not implemented");
    }

    public void updateAsciiStream(String columnName,
                                  InputStream x,
                                  int length) throws SQLException {
        throw new AssertionFailedError("MockResultSet updateAsciiStream not implemented");
    }

    public void updateBinaryStream(String columnName,
                                   InputStream x,
                                   int length) throws SQLException {
        throw new AssertionFailedError("MockResultSet updateBinaryStream not implemented");
    }

    public void updateCharacterStream(String columnName,
                                      Reader reader,
                                      int length) throws SQLException {
        throw new AssertionFailedError("MockResultSet updateCharacterStream not implemented");
    }

    public void updateObject(String columnName, Object x, int scale)
            throws SQLException {
        throw new AssertionFailedError("MockResultSet updateObject not implemented");
    }

    public void updateObject(String columnName, Object x) throws SQLException {
        throw new AssertionFailedError("MockResultSet updateObject not implemented");
    }

    public void insertRow() throws SQLException {
        throw new AssertionFailedError("MockResultSet insertRow not implemented");
    }

    public void updateRow() throws SQLException {
        throw new AssertionFailedError("MockResultSet updateRow not implemented");
    }

    public void deleteRow() throws SQLException {
        throw new AssertionFailedError("MockResultSet deleteRow not implemented");
    }

    public void refreshRow() throws SQLException {
        throw new AssertionFailedError("MockResultSet refreshRow not implemented");
    }

    public void cancelRowUpdates() throws SQLException {
        throw new AssertionFailedError("MockResultSet cancelRowUpdates not implemented");
    }

    public void moveToInsertRow() throws SQLException {
        throw new AssertionFailedError("MockResultSet moveToInsertRow not implemented");
    }

    public void moveToCurrentRow() throws SQLException {
        throw new AssertionFailedError("MockResultSet moveToCurrentRow not implemented");
    }

    public boolean wasNull() throws SQLException {
        throw new AssertionFailedError("MockResultSet wasNull not implemented");
    }

}
