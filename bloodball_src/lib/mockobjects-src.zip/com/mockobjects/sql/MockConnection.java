package com.mockobjects.sql;

import java.sql.*;
import java.util.Map;
import com.mockobjects.ExpectationCounter;
import com.mockobjects.ExpectationValue;
import com.mockobjects.MockObject;

public class MockConnection extends MockObject implements Connection {
    private ExpectationCounter myCommitCalls = new ExpectationCounter("MockConnection.commit");
    private ExpectationCounter myRollbackCalls = new ExpectationCounter("MockConnection.rollback");
    private ExpectationCounter myCloseCalls = new ExpectationCounter("MockConnection.close");

    private ExpectationValue myPrepareStatementString = new ExpectationValue("MockConnection.preparedStatementString");
    private PreparedStatement myPreparedStatement;
    private SQLException myStatementException = null;

    private ExpectationCounter myCreateStatementCalls = new ExpectationCounter("MockConnection.createStatement");
    private Statement myStatement;

    public MockConnection() {
        super();
    }

    public void setExpectedCloseCalls(int callCount) {
        myCloseCalls.setExpected(callCount);
    }

    public void setExpectedCommitCalls(int callCount) {
        myCommitCalls.setExpected(callCount);
    }

    public void setExpectedCreateStatementCalls(int calls) {
        myCreateStatementCalls.setExpected(calls);
    }

    public void setExpectedPrepareStatementString(String sql) {
        myPrepareStatementString.setExpected(sql);
    }

    public void setExpectedRollbackCalls(int callCount) {
        myRollbackCalls.setExpected(callCount);
    }

    public void setupPreparedStatement(PreparedStatement prepared) {
        myPreparedStatement = prepared;
    }

    public void setupStatement(Statement statement) {
        myStatement = statement;
    }

    public void setupThrowExceptionOnPrepareOrCreate(SQLException exception) {
        myStatementException = exception;
    }

    public void clearWarnings() throws SQLException {
    }

    public void close() throws SQLException {
        myCloseCalls.inc();
    }

    public void commit() throws SQLException {
        myCommitCalls.inc();
    }

    public Statement createStatement() throws SQLException {
        myCreateStatementCalls.inc();
        throwStatementExceptionIfAny();
        return myStatement;
    }

    public Statement createStatement(
            int resultSetType,
            int resultSetConcurrency)
            throws SQLException {
        throw new UnsupportedOperationException();
    }

    public boolean getAutoCommit() throws SQLException {
        throw new UnsupportedOperationException();
    }

    public String getCatalog() throws SQLException {
        throw new UnsupportedOperationException();
    }

    public DatabaseMetaData getMetaData()
            throws SQLException {
        throw new UnsupportedOperationException();
    }

    public int getTransactionIsolation() throws SQLException {
        throw new UnsupportedOperationException();
    }

    public Map getTypeMap() throws SQLException {
        throw new UnsupportedOperationException();
    }

    public SQLWarning getWarnings() throws SQLException {
        throw new UnsupportedOperationException();
    }

    public boolean isClosed() throws SQLException {
        throw new UnsupportedOperationException();
    }

    public boolean isReadOnly() throws SQLException {
        throw new UnsupportedOperationException();
    }

    public String nativeSQL(String sql) throws SQLException {
        throw new UnsupportedOperationException();
    }

    public CallableStatement prepareCall(String sql)
            throws SQLException {
        throw new UnsupportedOperationException();
    }

    public CallableStatement prepareCall(
            String sql,
            int resultSetType,
            int resultSetConcurrency)
            throws SQLException {
        throw new UnsupportedOperationException();
    }

    public PreparedStatement prepareStatement(String sql) throws SQLException {
        myPrepareStatementString.setActual(sql);
        throwStatementExceptionIfAny();
        return myPreparedStatement;
    }

    public PreparedStatement prepareStatement(
            String sql,
            int resultSetType,
            int resultSetConcurrency)
            throws SQLException {
        throw new UnsupportedOperationException();
    }

    public void rollback() throws SQLException {
        myRollbackCalls.inc();
    }

    public void setAutoCommit(boolean autoCommit)
            throws SQLException {
        throw new UnsupportedOperationException();
    }

    public void setCatalog(String catalog) throws SQLException {
        throw new UnsupportedOperationException();
    }

    public void setReadOnly(boolean readOnly) throws SQLException {
        throw new UnsupportedOperationException();
    }

    public void setTransactionIsolation(int level)
            throws SQLException {
        throw new UnsupportedOperationException();
    }

    public void setTypeMap(Map map) throws SQLException {
        throw new UnsupportedOperationException();
    }

    private void throwStatementExceptionIfAny() throws SQLException {
        if (null != myStatementException) {
            throw myStatementException;
        }
    }

}
