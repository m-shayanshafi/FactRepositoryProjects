package com.mockobjects.sql;

import java.sql.*;
import junit.framework.*;
import com.mockobjects.*;

public class MockStatement extends MockObject implements Statement {
    protected ExpectationCounter myCloseCalls = new ExpectationCounter("MockStatement.closeCalls");
    protected ExpectationCounter myExecuteCalls = new ExpectationCounter("MockStatement.executeCalls");
    protected ExpectationValue myQueryString = new ExpectationValue("MockStatement.queryString");
    protected MockResultSet myResultSet;

    private   int myUpdateCount = 0;
    private SQLException myExecuteException = null;

    public MockStatement() {
        super();
    }

    public void setExpectedExecuteCalls(int callCount) {
        myExecuteCalls.setExpected(callCount);
    }

    public void setExpectedQueryString(String queryString) {
        myQueryString.setExpected(queryString);
    }

    public void setExpectedCloseCalls(int callCount) {
        myCloseCalls.setExpected(callCount);
    }

    public void setupResultSet(MockResultSet aResultSet) {
        myResultSet = aResultSet;
    }

    public void setupThrowExceptionOnExecute(SQLException exception) {
        myExecuteException = exception;
    }

    public void setupUpdateCount(int updateCount) {
        myUpdateCount = updateCount;
    }

    protected void innerExecute() throws SQLException {
        myExecuteCalls.inc();
        if (null != myExecuteException) {
            throw myExecuteException;
        }
    }

    public void close() throws SQLException {
        myCloseCalls.inc();
    }

    public boolean execute(String sql) throws SQLException {
        throw new UnsupportedOperationException();
    }

    public ResultSet executeQuery(String sql) throws SQLException {
        myQueryString.setActual(sql);
        innerExecute();
        return myResultSet;
    }

    public int executeUpdate(String sql) throws SQLException {
        myQueryString.setActual(sql);
        innerExecute();
        return myUpdateCount;
    }

    public int getMaxFieldSize() throws SQLException {
        throw new UnsupportedOperationException();
    }

    public void setMaxFieldSize(int max) throws SQLException {
        throw new UnsupportedOperationException();
    }

    public int getMaxRows() throws SQLException {
        throw new UnsupportedOperationException();
    }

    public void setMaxRows(int max) throws SQLException {
        throw new UnsupportedOperationException();
    }

    public void setEscapeProcessing(boolean enable) throws SQLException {
        throw new UnsupportedOperationException();
    }

    public int getQueryTimeout() throws SQLException {
        throw new UnsupportedOperationException();
    }

    public void setQueryTimeout(int seconds) throws SQLException {
        throw new UnsupportedOperationException();
    }

    public void cancel() throws SQLException {
        throw new UnsupportedOperationException();
    }

    public SQLWarning getWarnings() throws SQLException {
        throw new UnsupportedOperationException();
    }

    public void clearWarnings() throws SQLException {
        throw new UnsupportedOperationException();
    }

    public void setCursorName(String name) throws SQLException {
        throw new UnsupportedOperationException();
    }

    public ResultSet getResultSet() throws SQLException {
        throw new UnsupportedOperationException();
    }

    public int getUpdateCount() throws SQLException {
        return myUpdateCount;
    }

    public boolean getMoreResults() throws SQLException {
        throw new UnsupportedOperationException();
    }

    public void setFetchDirection(int direction) throws SQLException {
        throw new UnsupportedOperationException();
    }

    public int getFetchDirection() throws SQLException {
        throw new UnsupportedOperationException();
    }

    public void setFetchSize(int rows) throws SQLException {
        throw new UnsupportedOperationException();
    }

    public int getFetchSize() throws SQLException {
        throw new UnsupportedOperationException();
    }

    public int getResultSetConcurrency() throws SQLException {
        throw new UnsupportedOperationException();
    }

    public int getResultSetType() throws SQLException {
        throw new UnsupportedOperationException();
    }

    public void addBatch(String sql) throws SQLException {
        throw new UnsupportedOperationException();
    }

    public void clearBatch() throws SQLException {
        throw new UnsupportedOperationException();
    }

    public int[] executeBatch() throws SQLException {
        throw new UnsupportedOperationException();
    }

    public Connection getConnection() throws SQLException {
        throw new UnsupportedOperationException();
    }

}
