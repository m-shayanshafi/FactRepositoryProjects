package com.mockobjects.sql;

import java.sql.SQLException;
import java.util.*;


/**
 * This is a simple implementation of a MockResultSet.
 * It verifies that the values fed to it have been retrieved.
 * These can be found by either column index or column name.
 * For basic java types (e.g. int, boolean), insert an instance of
 * the appropriate object (e.g. Integer, Boolean)
 * To force throwing a SQLException on a getter, set the corresponding value to be of type SQLException.
 */
public class MockSingleRowResultSet extends MockResultSet {
    private ExpectationSqlRow myRow = new ExpectationSqlRow("single row");
    private int myNextCallCount = 0;

    public MockSingleRowResultSet() {
        super();
    }

    public MockSingleRowResultSet(Object[] values) {
        this();
        addExpectedIndexedValues(values);
    }

    public MockSingleRowResultSet(String[] names, Object[] values) {
        this();
        addExpectedNamedValues(names, values);
    }

    public MockSingleRowResultSet(Map map) {
        this();
        addExpectedNamedValues(map);
    }

    public void addExpectedIndexedValues(Object[] values) {
        myRow.addExpectedIndexedValues(values);
    }

    public void addExpectedNamedValues(String[] names, Object[] values) {
        myRow.addExpectedNamedValues(names, values);
    }

    public void addExpectedNamedValues(Map map) {
        myRow.addExpectedNamedValues(map);
    }

    public boolean next() throws SQLException {
        myNextCalls.inc();
        myNextCallCount++;
        return myNextCallCount == 1;
    }

    public int getRow() throws SQLException {
        return myNextCallCount;
    }

    public Object getObject(int columnIndex) throws SQLException {
        return myRow.get(columnIndex);
    }

    public Object getObject(String columnName) throws SQLException {
        return myRow.get(columnName);
    }
}
