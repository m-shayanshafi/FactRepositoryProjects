package com.mockobjects.sql;

import java.sql.*;
import java.util.Calendar;
import java.io.Reader;
import java.math.BigDecimal;
import com.mockobjects.*;

public class MockPreparedStatement extends MockStatement implements PreparedStatement {
    private ExpectationSet mySetParameters = new ExpectationSet("MockPreparedStatement.setParameters");
    private ExpectationCounter myClearParametersCalls = new ExpectationCounter("MockPreparedStatement.clearParameters() calls");

    public MockPreparedStatement() {
        super();
    }

    public void addExpectedSetParameter(int parameterIndex, int intValue) {
        addExpectedSetParameter(parameterIndex, new Integer(intValue));
    }

    public void addExpectedSetParameter(int parameterIndex, Object parameterValue) {
        mySetParameters.addExpected(new MapEntry(new Integer(parameterIndex), parameterValue));
    }

    public void addExpectedSetParameters(Object[] parameters) {
        for (int i = 0; i < parameters.length; ++i) {
            addExpectedSetParameter(i + 1, parameters[i]);
        }
    }

    public void verify() {
        super.verify();
        mySetParameters.verify();
        myExecuteCalls.verify();
        myClearParametersCalls.verify();
    }

    public void clearParameters() throws SQLException {
        myClearParametersCalls.inc();
    }

    public boolean execute() throws SQLException {
        innerExecute();
        return false;
    }

    public void setExpectedClearParametersCalls(int callCount) {
        myClearParametersCalls.setExpected(callCount);
    }

    public void setExpectingNoSetParameters() {
        mySetParameters.setExpectNothing();
    }

    public ResultSet executeQuery() throws SQLException {
        return executeQuery("");
    }

    public int executeUpdate() throws SQLException {
        return executeUpdate("");
    }

    public void setInt(int parameterIndex, int x) throws SQLException {
        setObject(parameterIndex, new Integer(x));
    }

    public void setString(int parameterIndex, String x) throws SQLException {
        setObject(parameterIndex, x);
    }

    public void setTimestamp(int param, Timestamp timestamp) throws SQLException {
        setObject(param, timestamp);
    }

    public void setClob(int param, Clob clob) throws SQLException {
        setObject(param, clob);
    }

    public void setLong(int param, long aLong) throws SQLException {
        setObject(param, new Long(aLong));
    }

    public void addBatch() throws SQLException {
        throw new UnsupportedOperationException();
    }

    public void setNull(int param, int param1) throws SQLException {
        throw new UnsupportedOperationException();
    }

    public void setArray(int param, Array array) throws SQLException {
        setObject(param, array);
    }

    public void setShort(int param, short aShort) throws SQLException {
        setObject(param, new Short(aShort));
    }

    public void setTime(int param, Time time, Calendar calendar) throws SQLException {
        setObject(param, time);
    }

    public void setObject(int param, Object obj, int targetSqlType, int scale) throws SQLException {
        throw new UnsupportedOperationException();
    }

    public void setObject(int param, Object obj, int targetSqlType) throws SQLException {
        throw new UnsupportedOperationException();
    }

    public void setRef(int param, Ref ref) throws SQLException {
        setObject(param, ref);
    }

    public void setDate(int param, Date date) throws SQLException {
        setObject(param, date);
    }

    public void setFloat(int param, float aFloat) throws SQLException {
        setObject(param, new Float(aFloat));
    }

    public void setBlob(int param, Blob blob) throws SQLException {
        setObject(param, blob);
    }

    public void setCharacterStream(int param, Reader reader, int length) throws SQLException {
        throw new UnsupportedOperationException();
    }

    public void setAsciiStream(int param, java.io.InputStream inputStream, int length) throws SQLException {
        throw new UnsupportedOperationException();
    }

    public void setDate(int param, Date date, Calendar calendar) throws SQLException {
        setDate(param, date);
    }

    public void setBinaryStream(int param, java.io.InputStream inputStream, int length) throws SQLException {
        throw new UnsupportedOperationException();
    }

    public void setUnicodeStream(int param, java.io.InputStream inputStream, int length) throws SQLException {
        throw new UnsupportedOperationException();
    }

    public void setBytes(int param, byte[] values) throws SQLException {
        setObject(param, values);
    }

    public void setObject(int param, Object obj) throws SQLException {
        mySetParameters.addActual(new MapEntry(new Integer(param), obj));
    }

    public void setByte(int param, byte aByte) throws SQLException {
        setObject(param, new Byte(aByte));
    }

    public void setDouble(int param, double aDouble) throws SQLException {
        setObject(param, new Double(aDouble));
    }

    public ResultSetMetaData getMetaData() throws SQLException {
        throw new UnsupportedOperationException();
    }

    public void setTimestamp(int param, Timestamp timestamp, Calendar calendar) throws SQLException {
        throw new UnsupportedOperationException();
    }

    public void setTime(int param, Time time) throws SQLException {
        setObject(param, time);
    }

    public void setBoolean(int param, boolean aBoolean) throws SQLException {
        setObject(param, new Boolean(aBoolean));
    }

    public void setNull(int param, int param1, String typeName) throws SQLException {
        throw new UnsupportedOperationException();
    }

    public void setBigDecimal(int param, BigDecimal bigDecimal) throws SQLException {
        setObject(param, bigDecimal);
    }

}
