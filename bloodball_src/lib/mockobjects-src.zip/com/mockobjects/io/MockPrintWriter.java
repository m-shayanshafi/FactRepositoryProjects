package com.mockobjects.io;

import com.mockobjects.*;
import junit.framework.Assert;
import java.io.*;


/**
 * @author: steve@m3p.co.uk
 */

public class MockPrintWriter extends PrintWriter implements Verifiable {
    private ExpectationSegment mySegment = new ExpectationSegment("String segment");
    private ExpectationCounter myCloseCalls = new ExpectationCounter("close calls");

    public MockPrintWriter() {
        this(new StringWriter());
    }

    private MockPrintWriter(Writer writer) {
        super(writer);
    }

    public void close() {
        super.close();
        myCloseCalls.inc();
    }

    public void setExpectedCloseCalls(int calls) {
        myCloseCalls.setExpected(calls);
    }

    public void setExpectedSegment(String aString) {
        mySegment.setExpected(aString);
    }

    public void verify() {
        mySegment.verify();
        myCloseCalls.verify();
    }

    public void write(String s) {
        super.write(s);
        mySegment.setActual(s);
    }
}
