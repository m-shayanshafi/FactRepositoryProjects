package com.mockobjects;

public interface Verifiable {

    public abstract void verify();
}
