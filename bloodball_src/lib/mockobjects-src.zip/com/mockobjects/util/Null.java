package com.mockobjects.util;

public class Null {
    final private String myDescription;

    public Null() {
        this("null");
    }

    public Null(String description) {
        super();
        myDescription = description;
    }

    public boolean equals(Object other) {
        return other instanceof Null;
    }

    public String toString() {
        return myDescription;
    }
}
