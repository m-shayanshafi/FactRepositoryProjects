package com.mockobjects.util;

import junit.framework.AssertionFailedError;
import java.lang.reflect.Field;
import com.mockobjects.*;

public class Verifier {

    public Verifier() {
        super();
    }

    static public void verifyField(Field field, Object anObject) {
        try {
            field.setAccessible(true);
            Object fieldObject = field.get(anObject);
            if (fieldObject instanceof Verifiable) {
                ((Verifiable) fieldObject).verify();
            }
        } catch (IllegalAccessException ex) {
            throw new AssertionFailedError(
                "Could not access field: " + field.getName());
        }
    }

    static public void verifyObject(Object anObject) {
        verifyObjectFromClass(anObject, anObject.getClass());
    }

    static private void verifyObjectFromClass(Object anObject, Class aClass) {
        if (aClass.equals(Object.class)) {
            return;
        }
        verifyObjectFromClass(anObject, aClass.getSuperclass());

        Field[] fields = aClass.getDeclaredFields();
        for (int i = 0; i < fields.length; ++i) {
            verifyField(fields[i], anObject);
        }
    }
}
