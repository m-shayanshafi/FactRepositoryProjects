package com.mockobjects;

public interface Expectation extends Verifiable {

    public boolean hasExpectations();

    void setExpectNothing();

    public void setFailOnVerify();
}
