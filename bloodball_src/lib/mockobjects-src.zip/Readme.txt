Core library for implementing mock objects
and implementation for core java libraries
